// Plain JavaScript Portfolio Assistant (No React dependencies)

class PortfolioAssistant {
  constructor() {
    this.messages = [];
    this.isLoading = false;
    this.agentAvailable = true;
    this.userId = 'hackathon_user';
    this.sessionId = this.generateUUID();
    
    this.init();
  }

  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  init() {
    // Initialize with welcome message
    this.messages = [{
      role: 'assistant',
      content: 'Merhaba! Ben Fibabanka Portföy Asistanınız. Yatırımlarınızı yönetmenize nasıl yardımcı olabilirim?'
    }];
    
    this.render();
    this.setupEventListeners();
    this.checkAgentAvailability();
  }

  async checkAgentAvailability() {
    try {
      const response = await fetch('/api/check-agent');
      const data = await response.json();
      this.agentAvailable = data.available;
    } catch (error) {
      console.error('Agent check failed:', error);
      this.agentAvailable = false;
    }
    this.updateStatus();
  }

  async runPortfolioInteraction(userMessage) {
    if (!this.agentAvailable) {
      return "Üzgünüm, şu anda AI asistanı kullanılamıyor. Lütfen sistem yöneticisi ile iletişime geçin.";
    }

    try {
      const response = await fetch('/api/portfolio-interaction', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: this.userId,
          session_id: this.sessionId,
          user_message: userMessage
        })
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      return data.response;
    } catch (error) {
      console.error('Portfolio interaction failed:', error);
      return this.mockPortfolioResponse(userMessage);
    }
  }

  mockPortfolioResponse(userMessage) {
    const message = userMessage.toLowerCase();
    
    if (message.includes('55000') || message.includes('55.000')) {
      return `
## 💰 55.000 TL Yatırım Önerisi

Mevcut piyasa koşullarını değerlendirdikten sonra, ılımlı risk profili için aşağıdaki portföy önerisini hazırladım:

### 📊 Önerilen Portföy Dağılımı:
- **%40 (22.000 TL)** - Karma Fonlar (Garanti Portföy Karma Fon gibi)
- **%30 (16.500 TL)** - Devlet Tahvilleri/Eurobond Fonları
- **%20 (11.000 TL)** - BIST 30 Endeks Fonu
- **%10 (5.500 TL)** - Likit fon (acil durum rezervi)

### ✅ Bu önerinin avantajları:
- Diversifikasyon ile risk dağıtımı
- Orta vadeli getiri potansiyeli
- Piyasa dalgalanmalarına karşı koruma
- Likidite esnekliği

Bu önerilen portföyü onaylıyor musunuz?
      `;
    }
    
    if (message.includes('portföy') || message.includes('analiz')) {
      return `
## 📈 Portföy Analizi

### 💼 Güncel Durum:
- **Toplam Varlık**: Hesaplanıyor...
- **Risk Seviyesi**: Orta düzey
- **Çeşitlendirme**: İyi durumda

### 📊 Öneriler:
1. Teknoloji sektöründe pozisyon artırılabilir
2. Döviz kuru riskine karşı hedge araçları değerlendirilebilir
3. Gelecek ay yeniden dengeleme önerilir
      `;
    }

    return `
## 🤖 Fibabanka Portföy Asistanı

Size yardımcı olabilmek için şu konularda destek verebilirim:

- 💰 Yatırım önerileri ve portföy oluşturma
- 📊 Mevcut portföy analizi
- ⚠️ Risk değerlendirmesi
- 📈 Piyasa durumu analizi

*Not: Bu bir demo versiyondur. Gerçek yatırım kararları için profesyonel danışmanlık alınız.*
    `;
  }

  renderMessage(content) {
    return content
      .replace(/## (.*$)/gim, '<h2>$1</h2>')
      .replace(/### (.*$)/gim, '<h3>$1</h3>')
      .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/gim, '<em>$1</em>')
      .replace(/\n/g, '<br/>');
  }

  async handleSubmit(e) {
    e.preventDefault();
    const input = document.getElementById('messageInput');
    const userMessage = input.value.trim();
    
    if (!userMessage) return;

    input.value = '';
    this.isLoading = true;

    // Add user message
    this.messages.push({ role: 'user', content: userMessage });
    this.render();

    try {
      const response = await this.runPortfolioInteraction(userMessage);
      this.messages.push({ role: 'assistant', content: response });
    } catch (error) {
      console.error('Error:', error);
      this.messages.push({ 
        role: 'assistant', 
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.' 
      });
    }

    this.isLoading = false;
    this.render();
  }

  handleExampleScenario() {
    const exampleText = "Merhaba, 55.000 TL yatırım yapmak istiyorum. Mevcut piyasa koşullarına göre ılımlı bir riskle paramı nasıl değerlendirebilirim?";
    document.getElementById('messageInput').value = exampleText;
  }

  setupEventListeners() {
    const form = document.getElementById('messageForm');
    const exampleBtn = document.getElementById('exampleBtn');
    
    form.addEventListener('submit', (e) => this.handleSubmit(e));
    exampleBtn.addEventListener('click', () => this.handleExampleScenario());
  }

  updateStatus() {
    const statusEl = document.getElementById('status');
    if (this.agentAvailable) {
      statusEl.innerHTML = '<div class="status success">✅ AI sistemi aktif</div>';
    } else {
      statusEl.innerHTML = '<div class="status warning">⚠️ Demo modunda çalışıyor</div>';
    }
  }

  render() {
    const app = document.getElementById('app');
    
    const messagesHtml = this.messages.map(message => `
      <div class="message ${message.role}">
        <div class="message-content">
          ${this.renderMessage(message.content)}
        </div>
      </div>
    `).join('');

    const loadingHtml = this.isLoading ? `
      <div class="message assistant">
        <div class="message-content">
          <div class="loading">
            🤔 Asistanınız sizin için en iyi yatırım seçeneklerini düşünüyor...
          </div>
        </div>
      </div>
    ` : '';

    const exampleScenarioHtml = this.messages.length === 1 ? `
      <div class="example-scenario">
        <hr />
        <p>Yatırım hedefinizi yazarak başlayın veya bir örnek senaryo deneyin:</p>
        <button id="exampleBtn" class="example-button">
          💰 55.000 TL yatırım senaryosunu dene
        </button>
      </div>
    ` : '';

    app.innerHTML = `
      <div class="portfolio-assistant">
        <header class="header">
          <h1>📈 Fibabanka Portföy Asistanı (JavaScript Version)</h1>
          <p>Riskometre verileri ve yapay zeka ile yatırımlarınızı yönetin.</p>
          <div id="status"></div>
        </header>

        <div class="chat-container">
          <div class="messages">
            ${messagesHtml}
            ${loadingHtml}
          </div>

          ${exampleScenarioHtml}

          <form id="messageForm" class="input-form">
            <div class="input-container">
              <input
                type="text"
                id="messageInput"
                placeholder="Yatırım hedefinizi veya sorunuzu yazın..."
                class="message-input"
                ${this.isLoading ? 'disabled' : ''}
              />
              <button 
                type="submit" 
                class="send-button"
                ${this.isLoading ? 'disabled' : ''}
              >
                Gönder
              </button>
            </div>
          </form>
        </div>
      </div>
    `;

    this.updateStatus();
    this.setupEventListeners();
  }
}

// Initialize the app when DOM is loaded
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    new PortfolioAssistant();
  });
} else {
  // For Node.js environment
  console.log('Portfolio Assistant - JavaScript version ready');
  console.log('To run this in a browser, create an HTML file that includes this script.');
}
