import React, { useState, useEffect } from 'react';
import './ui_react.css';

const PortfolioAssistant = () => {
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [agentAvailable] = useState(false); // Set to false for demo mode
  const [userId] = useState('hackathon_user');
  const [sessionId] = useState(() => generateUUID());

  useEffect(() => {
    setMessages([{
      role: 'assistant',
      content: 'Merhaba! Ben Fibabanka Portföy Asistanınız. Yatırımlarınızı yönetmenize nasıl yardımcı olabilirim?'
    }]);
  }, []);

  function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  const mockPortfolioResponse = (userMessage) => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('55000') || message.includes('55.000')) {
      return `## 💰 55.000 TL Yatırım Önerisi

Mevcut piyasa koşullarını değerlendirdikten sonra, ılımlı risk profili için aşağıdaki portföy önerisini hazırladım:

### 📊 Önerilen Portföy Dağılımı:
- **%40 (22.000 TL)** - Karma Fonlar (Garanti Portföy Karma Fon gibi)
- **%30 (16.500 TL)** - Devlet Tahvilleri/Eurobond Fonları
- **%20 (11.000 TL)** - BIST 30 Endeks Fonu
- **%10 (5.500 TL)** - Likit fon (acil durum rezervi)

### ✅ Bu önerinin avantajları:
- Diversifikasyon ile risk dağıtımı
- Orta vadeli getiri potansiyeli
- Piyasa dalgalanmalarına karşı koruma
- Likidite esnekliği

Bu önerilen portföyü onaylıyor musunuz?`;
    }

    if (message.includes('portföy') || message.includes('analiz')) {
      return `## 📈 Portföy Analizi

### 💼 Güncel Durum:
- **Toplam Varlık**: Hesaplanıyor...
- **Risk Seviyesi**: Orta düzey
- **Çeşitlendirme**: İyi durumda

### 📊 Öneriler:
1. Teknoloji sektöründe pozisyon artırılabilir
2. Döviz kuru riskine karşı hedge araçları değerlendirilebilir
3. Gelecek ay yeniden dengeleme önerilir`;
    }

    return `## 🤖 Fibabanka Portföy Asistanı

Size yardımcı olabilmek için şu konularda destek verebilirim:

- 💰 Yatırım önerileri ve portföy oluşturma
- 📊 Mevcut portföy analizi
- ⚠️ Risk değerlendirmesi
- 📈 Piyasa durumu analizi

*Not: Bu bir demo versiyondur. Gerçek yatırım kararları için profesyonel danışmanlık alınız.*`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentMessage.trim()) return;

    const userMessage = currentMessage;
    setCurrentMessage('');
    setIsLoading(true);

    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);

    // Simulate AI thinking time
    setTimeout(() => {
      const response = mockPortfolioResponse(userMessage);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      setIsLoading(false);
    }, 1500);
  };

  const handleExampleScenario = () => {
    setCurrentMessage("Merhaba, 55.000 TL yatırım yapmak istiyorum. Mevcut piyasa koşullarına göre ılımlı bir riskle paramı nasıl değerlendirebilirim?");
  };

  const renderMessage = (content) => {
    return content
      .replace(/## (.*$)/gim, '<h2>$1</h2>')
      .replace(/### (.*$)/gim, '<h3>$1</h3>')
      .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/gim, '<em>$1</em>')
      .replace(/\n/g, '<br/>');
  };

  return (
    <div className="portfolio-assistant">
      <header className="header">
        <h1>📈 Fibabanka Portföy Asistanı (React Version)</h1>
        <p>Riskometre verileri ve yapay zeka ile yatırımlarınızı yönetin.</p>
        
        <div className="status warning">⚠️ Demo modunda çalışıyor</div>
      </header>

      <div className="chat-container">
        <div className="messages">
          {messages.map((message, index) => (
            <div key={index} className={`message ${message.role}`}>
              <div className="message-content">
                <div 
                  dangerouslySetInnerHTML={{ 
                    __html: renderMessage(message.content) 
                  }} 
                />
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="message assistant">
              <div className="message-content">
                <div className="loading">
                  🤔 Asistanınız sizin için en iyi yatırım seçeneklerini düşünüyor...
                </div>
              </div>
            </div>
          )}
        </div>

        {messages.length === 1 && (
          <div className="example-scenario">
            <hr />
            <p>Yatırım hedefinizi yazarak başlayın veya bir örnek senaryo deneyin:</p>
            <button 
              className="example-button"
              onClick={handleExampleScenario}
            >
              💰 55.000 TL yatırım senaryosunu dene
            </button>
          </div>
        )}

        <form onSubmit={handleSubmit} className="input-form">
          <div className="input-container">
            <input
              type="text"
              value={currentMessage}
              onChange={(e) => setCurrentMessage(e.target.value)}
              placeholder="Yatırım hedefinizi veya sorunuzu yazın..."
              disabled={isLoading}
              className="message-input"
            />
            <button 
              type="submit" 
              disabled={isLoading || !currentMessage.trim()}
              className="send-button"
            >
              Gönder
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PortfolioAssistant;
