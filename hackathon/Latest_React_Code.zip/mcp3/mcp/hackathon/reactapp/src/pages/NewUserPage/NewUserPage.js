import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import NavBar from '../../components/NavBar/NavBar';
import './NewUserPage.css';

function NewUserPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    idNumber: '',
    riskProfile: 'moderate'
  });
  const [step, setStep] = useState(1);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const nextStep = () => {
    setStep(step + 1);
  };

  const prevStep = () => {
    setStep(step - 1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Normally we would submit to a server here
    navigate("/portfolio"); // Redirect to portfolio assistant
  };

  return (
    <div className="new-user-wrapper">
      <NavBar />
      <div className="navbar-spacer"></div>
      <div className="new-user-container">
        <div className="registration-card">
          <h1>Yeni Kullanıcı Kaydı</h1>
          <p className="subtitle">Portföy asistanınızı kullanmak için lütfen kayıt olun</p>

          <div className="progress-bar">
            <div className={`progress-step ${step >= 1 ? 'active' : ''}`}>Kişisel Bilgiler</div>
            <div className={`progress-step ${step >= 2 ? 'active' : ''}`}>Risk Profili</div>
            <div className={`progress-step ${step >= 3 ? 'active' : ''}`}>Onay</div>
          </div>

          <form onSubmit={handleSubmit}>
            {step === 1 && (
              <div className="form-step">
                <div className="form-group">
                  <label>Ad Soyad</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>E-posta</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Telefon</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>TC Kimlik No</label>
                  <input
                    type="text"
                    name="idNumber"
                    value={formData.idNumber}
                    onChange={handleChange}
                    required
                    minLength="11"
                    maxLength="11"
                  />
                </div>
                <button type="button" onClick={nextStep} className="next-button">
                  İleri
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="form-step">
                <div className="form-group">
                  <label>Risk Profiliniz</label>
                  <select
                    name="riskProfile"
                    value={formData.riskProfile}
                    onChange={handleChange}
                  >
                    <option value="conservative">Konservatif - Düşük Risk</option>
                    <option value="moderate">Ilımlı - Orta Risk</option>
                    <option value="aggressive">Agresif - Yüksek Risk</option>
                  </select>
                </div>
                <div className="risk-description">
                  <h3>Ilımlı Risk Profili</h3>
                  <p>Bu profil, makul bir büyüme hedeflerken orta düzeyde risk alabilecek yatırımcılar için uygundur. Portföyünüz hisse senetleri, tahviller ve güvenli yatırımlar arasında dengeli bir şekilde dağıtılacaktır.</p>
                </div>
                <div className="button-group">
                  <button type="button" onClick={prevStep} className="back-button">
                    Geri
                  </button>
                  <button type="button" onClick={nextStep} className="next-button">
                    İleri
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="form-step">
                <h3>Bilgilerinizi Onaylayın</h3>
                <div className="summary">
                  <div className="summary-item">
                    <span>Ad Soyad:</span>
                    <span>{formData.name}</span>
                  </div>
                  <div className="summary-item">
                    <span>E-posta:</span>
                    <span>{formData.email}</span>
                  </div>
                  <div className="summary-item">
                    <span>Telefon:</span>
                    <span>{formData.phone}</span>
                  </div>
                  <div className="summary-item">
                    <span>TC Kimlik No:</span>
                    <span>{formData.idNumber}</span>
                  </div>
                  <div className="summary-item">
                    <span>Risk Profili:</span>
                    <span>{formData.riskProfile === 'conservative' ? 'Konservatif' : 
                           formData.riskProfile === 'moderate' ? 'Ilımlı' : 'Agresif'}</span>
                  </div>
                </div>
                <div className="button-group">
                  <button type="button" onClick={prevStep} className="back-button">
                    Geri
                  </button>
                  <button type="submit" className="submit-button">
                    Kaydı Tamamla
                  </button>
                </div>
              </div>
            )}
          </form>

          <button className="home-link" onClick={() => navigate("/")}>
            Ana Sayfaya Dön
          </button>
        </div>

        <div className="portfolio-shortcut">
          <h2>Yatırım Danışmanımızı Keşfedin</h2>
          <p>
            Fibabanka'nın yapay zeka destekli portföy asistanı ile tanışın. 
            Hesap oluşturmadan da yatırım önerilerimizi inceleyebilirsiniz.
          </p>
          <button onClick={() => navigate("/portfolio")} className="portfolio-button">
            Portföy Asistanını Deneyin
          </button>
        </div>
      </div>
    </div>
  );
}

export default NewUserPage;
