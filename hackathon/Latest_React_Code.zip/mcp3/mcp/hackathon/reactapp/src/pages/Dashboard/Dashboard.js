import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../../components/NavBar/NavBar';
import './Dashboard.css';

// API base URL - consistent with other components
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? '' 
  : 'http://localhost:8000';

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('accounts');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // State for real data
  const [portfolioData, setPortfolioData] = useState(null);
  const [aiRecommendationsData, setAiRecommendationsData] = useState(null);
  const [marketData, setMarketData] = useState(null);
  const [bankAccounts, setBankAccounts] = useState(null);
  
  // Fetch dashboard data from API
  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        const response = await fetch(`${API_BASE_URL}/api/dashboard-data`);
        if (!response.ok) {
          throw new Error(`HTTP error ${response.status}`);
        }
        const data = await response.json();
        
        // Update state with real data
        setPortfolioData(data.portfolio_data);
        setAiRecommendationsData(data.ai_recommendations_data);
        setMarketData(data.market_data);
        setBankAccounts(mockBankAccounts); // In the future, replace with real data
        setError(null);
      } catch (err) {
        console.error("Failed to fetch dashboard data:", err);
        setError("Failed to load dashboard data. Please try again later.");
        
        // Use fallback mock data
        setPortfolioData(mockPortfolioData);
        setAiRecommendationsData(mockAiRecommendationsData);
        setMarketData(mockMarketData);
        setBankAccounts(mockBankAccounts);
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  // Mock bank account data based on the image
  const mockBankAccounts = {
    balanceHistory: [1200, 1250, 1130, 1300, 1440, 1390, 1500],
    accounts: [
      { 
        id: 1, 
        name: "Fibabanka", 
        logo: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='%230088cc' d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z'/%3E%3C/svg%3E",
        balance: 12500.00,
        investmentTypes: [
          { name: "Kiraz Hesap", amount: 8500.00, interestRate: "28%" },
          { name: "Vadeli Mevduat", amount: 4000.00, interestRate: "25%" }
        ]
      },
      {
        id: 2,
        name: "Garanti Bankası",
        logo: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='%2300a651' d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z'/%3E%3C/svg%3E",
        balance: 3000.00,
        investmentTypes: [
          { name: "Vadesiz Hesap", amount: 3000.00, interestRate: "0%" }
        ]
      },
      {
        id: 3,
        name: "Ziraat Bankası",
        logo: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='%23e30613' d='M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z'/%3E%3C/svg%3E",
        balance: 15000.00,
        investmentTypes: [
          { name: "Altın Hesabı", amount: 10000.00, amount2: "115 gram" },
          { name: "Vadeli Mevduat", amount: 5000.00, interestRate: "24.5%" }
        ]
      }
    ],
    assets: [
      // Crypto assets removed
      { symbol: "THYAO", name: "Türk Hava Yolları", price: 29.62, change: 2.3, holdings: 150, value: 4443.00 },
      { symbol: "EREGL", name: "Ereğli Demir Çelik", price: 42.15, change: -0.8, holdings: 85, value: 3582.75 },
      { symbol: "KCHOL", name: "Koç Holding", price: 56.30, change: 1.1, holdings: 65, value: 3659.50 },
      { symbol: "BIMAS", name: "BİM Mağazaları", price: 62.40, change: 0.5, holdings: 50, value: 3120.00 }
    ],
    investmentFunds: [
      { code: "GAF", name: "Garanti Portföy Altın", price: 7.85, change: 0.8, holdings: 420, value: 3297.00 },
      { code: "TI4", name: "İş Portföy BIST 30", price: 4.25, change: 1.5, holdings: 850, value: 3612.50 },
      { code: "YEF", name: "Yapı Kredi Eurobond", price: 9.15, change: -0.3, holdings: 380, value: 3477.00 }
    ],
    topInvestments: [
      { name: "THYAO", type: "gainer", change: 5.3 },
      { name: "GARAN", type: "loser", change: -2.1 }
    ]
  };
  
  // Fallback mock data in case the API fails
  const mockPortfolioData = {
    totalValue: 325750.42,
    growth: 12.3,
    assetAllocation: [
      { name: 'Hisse Senetleri', value: 40 },
      { name: 'Tahvil/Bono', value: 30 },
      { name: 'Nakit', value: 20 },
      { name: 'Altın', value: 10 }
    ],
    recentTransactions: [
      { date: '2023-10-15', description: 'THYAO Alış', amount: -15000, type: 'buy' },
      { date: '2023-10-10', description: 'Temettü Ödemesi', amount: 1250, type: 'dividend' },
      { date: '2023-10-05', description: 'YKBNK Satış', amount: 22000, type: 'sell' },
      { date: '2023-09-28', description: 'GARAN Alış', amount: -18500, type: 'buy' }
    ]
  };
  
  const mockAiRecommendationsData = {
    recommendations: [
      {
        id: 1,
        date: '2023-08-15',
        assets: [
          { symbol: 'THYAO', name: 'Türk Hava Yolları', allocation: 25, expectedReturn: 12, actualReturn: 15.7 },
          { symbol: 'GARAN', name: 'Garanti Bankası', allocation: 20, expectedReturn: 8, actualReturn: 6.2 },
          { symbol: 'KRDMD', name: 'Kardemir', allocation: 15, expectedReturn: 10, actualReturn: 11.3 },
          { symbol: 'EREGL', name: 'Ereğli Demir Çelik', allocation: 30, expectedReturn: 7.5, actualReturn: 9.8 },
          { symbol: 'SISE', name: 'Şişe Cam', allocation: 10, expectedReturn: 9, actualReturn: 8.5 }
        ],
        initialInvestment: 50000,
        currentValue: 56850,
        expectedReturnTotal: 9.2,
        actualReturnTotal: 13.7,
        performanceDifference: 4.5,
        status: 'outperformed',
        notes: 'Özellikle havacılık sektöründeki yükseliş beklentileri aştı.'
      },
      {
        id: 2,
        date: '2023-09-22',
        assets: [
          { symbol: 'VAKBN', name: 'Vakıfbank', allocation: 35, expectedReturn: 11, actualReturn: 8.3 },
          { symbol: 'KOZAL', name: 'Koza Altın', allocation: 25, expectedReturn: 15, actualReturn: 17.2 },
          { symbol: 'AKBNK', name: 'Akbank', allocation: 20, expectedReturn: 9, actualReturn: 7.1 },
          { symbol: 'BIMAS', name: 'BİM Mağazaları', allocation: 20, expectedReturn: 6, actualReturn: 9.4 }
        ],
        initialInvestment: 75000,
        currentValue: 80625,
        expectedReturnTotal: 10.5,
        actualReturnTotal: 7.5,
        performanceDifference: -3.0,
        status: 'underperformed',
        notes: 'Bankacılık sektöründeki beklenmedik düzenlemeler getiriyi olumsuz etkiledi.'
      },
      {
        id: 3,
        date: '2023-11-10',
        assets: [
          { symbol: 'TUPRS', name: 'Tüpraş', allocation: 30, expectedReturn: 8, actualReturn: 10.8 },
          { symbol: 'SAHOL', name: 'Sabancı Holding', allocation: 25, expectedReturn: 7, actualReturn: 7.2 },
          { symbol: 'TAVHL', name: 'TAV Havalimanları', allocation: 25, expectedReturn: 12, actualReturn: 14.5 },
          { symbol: 'PGSUS', name: 'Pegasus', allocation: 20, expectedReturn: 14, actualReturn: 15.7 }
        ],
        initialInvestment: 100000,
        currentValue: 112300,
        expectedReturnTotal: 9.8,
        actualReturnTotal: 12.3,
        performanceDifference: 2.5,
        status: 'outperformed',
        notes: 'Enerji ve ulaşım sektörlerinde güçlü performans.'
      }
    ],
    // Aggregated performance statistics
    totalInvestmentAmount: 225000,
    totalCurrentValue: 249775,
    averageExpectedReturn: 9.8,
    averageActualReturn: 11.1,
    overallPerformance: 1.3,
    successRate: 66.7, // Percentage of recommendations that met or exceeded expectations
    bestPerformer: { symbol: 'THYAO', return: 15.7 },
    worstPerformer: { symbol: 'AKBNK', return: 7.1 }
  };

  // Market data (unchanged)
  const mockMarketData = {
    indices: [
      { name: 'BIST100', value: 9325.42, change: 1.2 },
      { name: 'BIST30', value: 9948.76, change: 0.8 },
      { name: 'BIST Bank', value: 5432.21, change: -0.5 }
    ],
    currencies: [
      { name: 'USD/TRY', value: 32.55, change: -0.3 },
      { name: 'EUR/TRY', value: 34.80, change: -0.1 },
      { name: 'GBP/TRY', value: 40.12, change: 0.2 }
    ],
    commodities: [
      { name: 'Altın (gram)', value: 2150.75, change: 0.8 },
      { name: 'Brent Petrol', value: 75.32, change: -1.2 },
      { name: 'Gümüş (ons)', value: 28.45, change: 0.5 }
    ]
  };
  
  const showTooltip = (event, day, value) => {
    const tooltip = document.getElementById('chartTooltip');
    if (tooltip) {
      // Get the SVG element's position
      const svg = event.target.closest('svg');
      const svgRect = svg.getBoundingClientRect();
      const pointRect = event.target.getBoundingClientRect();
      
      // Calculate position relative to the SVG
      const tooltipX = pointRect.left - svgRect.left + pointRect.width/2;
      const tooltipY = pointRect.top - svgRect.top;
      
      // Set tooltip content
      tooltip.querySelector('.tooltip-date').textContent = day;
      tooltip.querySelector('.tooltip-value').textContent = `₺ ${value.toLocaleString('tr-TR', {minimumFractionDigits: 2})}`;
      
      // Position tooltip
      tooltip.style.left = `${tooltipX}px`;
      tooltip.style.top = `${tooltipY}px`;
      tooltip.classList.add('visible');
    }
  };

  const hideTooltip = () => {
    const tooltip = document.getElementById('chartTooltip');
    if (tooltip) {
      tooltip.classList.remove('visible');
    }
  };

  const renderContent = () => {
    if (loading) {
      return <div className="loading-container">Veriler yükleniyor...</div>;
    }
    
    if (error) {
      return (
        <div className="error-container">
          <p>{error}</p>
          <p>Demo veriler gösteriliyor.</p>
        </div>
      );
    }
    
    switch(activeTab) {
      case 'accounts':
        return (
          <div className="dashboard-overview">
            {/* Add Streamlit navigation button */}
            <div className="streamlit-button-container">
              <a 
                href="http://localhost:8501/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="streamlit-button"
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
                </svg>
                Portfi Portföy Asistanım
              </a>
            </div>
            
            <div className="dashboard-layout">
              {/* Left Column - Chart and AI Performance */}
              <div className="dashboard-column main-column">
                {/* Balance Chart Card */}
                <div className="dashboard-card balance-chart-card">
                  <h2>Total Portfolio Value</h2>
                  <div className="total-balance">
                    <span className="currency">₺</span>
                    <span className="amount">
                      {(
                        bankAccounts.accounts.reduce((total, acc) => total + acc.balance, 0) +
                        bankAccounts.assets.reduce((total, asset) => total + asset.value, 0) +
                        bankAccounts.investmentFunds.reduce((total, fund) => total + fund.value, 0)
                      ).toLocaleString('tr-TR', {minimumFractionDigits: 2})}
                    </span>
                  </div>
                  
                  {/* Weekly Balance History heading */}
                  <h3 className="weekly-balance-heading">Weekly Balance History</h3>
                  
                  {/* Portfolio visualization */}
                  <div className="portfolio-visualization">
                    <div className="portfolio-breakdown-chart">
                      <div className="donut-chart">
                        <div className="donut-hole"></div>
                      </div>
                      <div className="breakdown-legend">
                        <div className="legend-item">
                          <div className="legend-color bank-accounts"></div>
                          <span className="legend-label">Banka Hesapları</span>
                          <span className="legend-value">45%</span>
                        </div>
                        <div className="legend-item">
                          <div className="legend-color stocks"></div>
                          <span className="legend-label">Hisse Senetleri</span>
                          <span className="legend-value">25%</span>
                        </div>
                        <div className="legend-item">
                          <div className="legend-color funds"></div>
                          <span className="legend-label">Yatırım Fonları</span>
                          <span className="legend-value">20%</span>
                        </div>
                        <div className="legend-item">
                          <div className="legend-color other"></div>
                          <span className="legend-label">Diğer</span>
                          <span className="legend-value">10%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* AI Performance Summary - Compact version below chart */}
                  <div className="ai-summary-card">
                    <div className="ai-performance-header">
                      <div className="ai-performance-status">
                        <div className="ai-status-indicator success"></div>
                        <span>Öneriler beklentilerin üzerinde</span>
                      </div>
                      <div className="ai-performance-value">
                        <span className="currency">+</span>
                        <span className="amount">2.5%</span>
                      </div>
                    </div>
                    
                    <div className="ai-performance-metrics">
                      <div className="ai-metric-item">
                        <div className="ai-metric-label">Son Öneri</div>
                        <div className="ai-metric-value">Enerji Sektörü</div>
                      </div>
                      <div className="ai-metric-item">
                        <div className="ai-metric-label">Başarı Oranı</div>
                        <div className="ai-metric-value">68%</div>
                      </div>
                      <div className="ai-metric-item">
                        <div className="ai-metric-label">En İyi Performans</div>
                        <div className="ai-metric-value positive">THYAO +15.7%</div>
                      </div>
                    </div>
                    
                    <div className="action-link" onClick={() => setActiveTab('ai-performance')}>
                      Detaylı AI performans raporunu görüntüle
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">
                        <path d="M13.172 12l-4.95-4.95 1.414-1.414L16 12l-6.364 6.364-1.414-1.414z" fill="currentColor"/>
                      </svg>
                    </div>
                  </div>
                  
                  <div className="balance-chart">
                    {/* Y-axis labels with more spacing */}
                    <div className="chart-y-labels">
                      <div className="y-label">₺1,500</div>
                      <div className="y-label">₺1,375</div>
                      <div className="y-label">₺1,250</div>
                      <div className="y-label">₺1,125</div>
                      <div className="y-label">₺1,000</div>
                    </div>
                    
                    <div className="chart-title">Weekly Balance History</div>
                    
                    <div className="chart-container">
                      <svg viewBox="0 0 300 100" className="line-chart">
                        <defs>
                          <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#FFCA28" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#FFCA28" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                        
                        {/* Grid lines */}
                        <line x1="0" y1="20" x2="300" y2="20" className="chart-grid-line" />
                        <line x1="0" y1="40" x2="300" y2="40" className="chart-grid-line" />
                        <line x1="0" y1="60" x2="300" y2="60" className="chart-grid-line" />
                        <line x1="0" y1="80" x2="300" y2="80" className="chart-grid-line" />
                        
                        {/* Line path based on mock data */}
                        <path 
                          d={`M 15,${100 - (bankAccounts.balanceHistory[0]/1500*100)} 
                             L ${15 + 270/6},${100 - (bankAccounts.balanceHistory[1]/1500*100)} 
                             L ${15 + 270/6*2},${100 - (bankAccounts.balanceHistory[2]/1500*100)} 
                             L ${15 + 270/6*3},${100 - (bankAccounts.balanceHistory[3]/1500*100)} 
                             L ${15 + 270/6*4},${100 - (bankAccounts.balanceHistory[4]/1500*100)} 
                             L ${15 + 270/6*5},${100 - (bankAccounts.balanceHistory[5]/1500*100)} 
                             L 285,${100 - (bankAccounts.balanceHistory[6]/1500*100)}`}
                          fill="none"
                          stroke="#FFCA28"
                          strokeWidth="3"
                        />
                        
                        {/* Area below the line */}
                        <path 
                          d={`M 15,${100 - (bankAccounts.balanceHistory[0]/1500*100)} 
                             L ${15 + 270/6},${100 - (bankAccounts.balanceHistory[1]/1500*100)} 
                             L ${15 + 270/6*2},${100 - (bankAccounts.balanceHistory[2]/1500*100)} 
                             L ${15 + 270/6*3},${100 - (bankAccounts.balanceHistory[3]/1500*100)} 
                             L ${15 + 270/6*4},${100 - (bankAccounts.balanceHistory[4]/1500*100)} 
                             L ${15 + 270/6*5},${100 - (bankAccounts.balanceHistory[5]/1500*100)} 
                             L 285,${100 - (bankAccounts.balanceHistory[6]/1500*100)}
                             L 285,100 L 15,100 Z`}
                          fill="url(#gradient)"
                        />
                        
                        {/* Data points with hover effect - adjusted X coordinates to match the path */}
                        <circle 
                          cx="15" 
                          cy={100 - (bankAccounts.balanceHistory[0]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Monday', bankAccounts.balanceHistory[0])}
                          onMouseOut={hideTooltip}
                        />
                        <circle 
                          cx={15 + 270/6} 
                          cy={100 - (bankAccounts.balanceHistory[1]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Tuesday', bankAccounts.balanceHistory[1])}
                          onMouseOut={hideTooltip}
                        />
                        <circle 
                          cx={15 + 270/6*2} 
                          cy={100 - (bankAccounts.balanceHistory[2]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Wednesday', bankAccounts.balanceHistory[2])}
                          onMouseOut={hideTooltip}
                        />
                        <circle 
                          cx={15 + 270/6*3} 
                          cy={100 - (bankAccounts.balanceHistory[3]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Thursday', bankAccounts.balanceHistory[3])}
                          onMouseOut={hideTooltip}
                        />
                        <circle 
                          cx={15 + 270/6*4} 
                          cy={100 - (bankAccounts.balanceHistory[4]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Friday', bankAccounts.balanceHistory[4])}
                          onMouseOut={hideTooltip}
                        />
                        <circle 
                          cx={15 + 270/6*5} 
                          cy={100 - (bankAccounts.balanceHistory[5]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Saturday', bankAccounts.balanceHistory[5])}
                          onMouseOut={hideTooltip}
                        />
                        <circle 
                          cx="285" 
                          cy={100 - (bankAccounts.balanceHistory[6]/1500*100)} 
                          r="4" 
                          className="data-point"
                          onMouseOver={(e) => showTooltip(e, 'Sunday', bankAccounts.balanceHistory[6])}
                          onMouseOut={hideTooltip}
                        />
                      </svg>
                      
                      {/* Tooltip element */}
                      <div id="chartTooltip" className="chart-tooltip">
                        <div className="tooltip-date">Monday</div>
                        <div className="tooltip-value">₺ 1,200.00</div>
                      </div>
                    </div>
                    
                    <div className="chart-labels">
                      <span>Mon</span>
                      <span>Tue</span>
                      <span>Wed</span>
                      <span>Thu</span>
                      <span>Fri</span>
                      <span>Sat</span>
                      <span>Sun</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Right Column - Accounts, Stocks, and Funds */}
              <div className="dashboard-column side-column">
                {/* Bank Accounts Card */}
                <div className="dashboard-card accounts-card">
                  <h2>Bank Accounts</h2>
                  <div className="accounts-list">
                    {bankAccounts.accounts.map(account => (
                      <div key={account.id} className="account-item">
                        <div className="account-header">
                          <div className="account-logo-name">
                            <div className="account-logo">
                              <img src={account.logo} alt={account.name} />
                            </div>
                            <div className="account-name">{account.name}</div>
                          </div>
                          <div className="account-balance">₺ {account.balance.toLocaleString('tr-TR', {minimumFractionDigits: 2})}</div>
                        </div>
                        
                        {/* Investment types for each account */}
                        {account.investmentTypes && account.investmentTypes.length > 0 && (
                          <div className="investment-types">
                            {account.investmentTypes.map((investment, idx) => (
                              <div key={idx} className="investment-type">
                                <div className="investment-type-name">{investment.name}</div>
                                <div className="investment-type-details">
                                  <div className="investment-amount">
                                    ₺ {investment.amount.toLocaleString('tr-TR', {minimumFractionDigits: 2})}
                                    {investment.amount2 && ` (${investment.amount2})`}
                                  </div>
                                  {investment.interestRate && (
                                    <div className="investment-rate">{investment.interestRate}</div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Stocks Card */}
                <div className="dashboard-card stocks-card">
                  <h2>Stocks</h2>
                  <div className="assets-table-wrapper">
                    <table className="assets-table">
                      <thead>
                        <tr>
                          <th>Symbol</th>
                          <th>Price</th>
                          <th>Change</th>
                          <th>Value</th>
                        </tr>
                      </thead>
                      <tbody>
                        {bankAccounts.assets.map(asset => (
                          <tr key={asset.symbol}>
                            <td><strong>{asset.symbol}</strong></td>
                            <td>₺{asset.price.toFixed(2)}</td>
                            <td className={asset.change >= 0 ? 'positive' : 'negative'}>
                              {asset.change >= 0 ? '+' : ''}{asset.change}%
                            </td>
                            <td>₺{asset.value.toLocaleString('tr-TR', {minimumFractionDigits: 2})}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                
                {/* Investment Funds Card */}
                <div className="dashboard-card funds-card">
                  <h2>Investment Funds</h2>
                  <div className="assets-table-wrapper">
                    <table className="assets-table">
                      <thead>
                        <tr>
                          <th>Code</th>
                          <th>Name</th>
                          <th>Change</th>
                          <th>Value</th>
                        </tr>
                      </thead>
                      <tbody>
                        {bankAccounts.investmentFunds.map(fund => (
                          <tr key={fund.code}>
                            <td><strong>{fund.code}</strong></td>
                            <td>{fund.name}</td>
                            <td className={fund.change >= 0 ? 'positive' : 'negative'}>
                              {fund.change >= 0 ? '+' : ''}{fund.change}%
                            </td>
                            <td>₺{fund.value.toLocaleString('tr-TR', {minimumFractionDigits: 2})}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="news-ticker">
              <div className="ticker-items">
                <span>🔶 BIST 100 endeksi rekor seviyeye ulaştı</span>
                <span>🔶 Merkez Bankası faiz kararını açıkladı</span>
                <span>🔶 Altın fiyatları yükselişte</span>
                <span>🔶 Ekonomi 2. çeyrekte %3.8 büyüdü</span>
              </div>
            </div>
          </div>
        );
        
      case 'portfolio':
        return (
          <div className="portfolio-overview">
            <div className="overview-header">
              <h2>Portföy Değeri</h2>
              <div className="overview-value">
                <span className="value">{portfolioData.totalValue.toLocaleString('tr-TR')} TL</span>
                <span className={`change ${portfolioData.growth >= 0 ? 'positive' : 'negative'}`}>
                  {portfolioData.growth >= 0 ? '+' : ''}{portfolioData.growth}%
                </span>
              </div>
            </div>
            
            <div className="dashboard-grid">
              <div className="dashboard-card">
                <h3>Varlık Dağılımı</h3>
                <div className="asset-allocation">
                  {portfolioData.assetAllocation.map((asset, index) => (
                    <div key={index} className="allocation-item">
                      <div className="allocation-label">
                        <div className={`allocation-indicator ${asset.name.toLowerCase().replace(/[^a-z0-9]/g, '')}`}></div>
                        {asset.name}
                      </div>
                      <div className="allocation-value">{asset.value}%</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="dashboard-card">
                <h3>Son İşlemler</h3>
                <div className="transactions-list">
                  {portfolioData.recentTransactions.map((transaction, index) => (
                    <div key={index} className={`transaction-item ${transaction.type}`}>
                      <div className="transaction-info">
                        <div className="transaction-date">{new Date(transaction.date).toLocaleDateString('tr-TR')}</div>
                        <div className="transaction-description">{transaction.description}</div>
                      </div>
                      <div className="transaction-amount">
                        {transaction.amount > 0 ? '+' : ''}{transaction.amount.toLocaleString('tr-TR')} TL
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="action-buttons">
              <button className="action-button primary" onClick={() => navigate('/portfolio')}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                  <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm-1-11v6h2v-6h-2zm0-4v2h2V7h-2z" fill="currentColor"/>
                </svg>
                Portföy Asistanı
              </button>
              <button className="action-button secondary" onClick={() => navigate('/transferMoney')}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                  <path d="M14 13.5V8L7 14l7 6v-5.5h3v-6h-3z" fill="currentColor"/>
                </svg>
                Para Transferi
              </button>
            </div>
          </div>
        );
      
      case 'market':
        return (
          <div className="market-overview">
            <h2>Piyasa Verileri</h2>
            
            <div className="dashboard-grid">
              <div className="dashboard-card">
                <h3>Borsa Endeksleri</h3>
                <div className="market-data-list">
                  {marketData.indices.map((index, i) => (
                    <div key={i} className="market-data-item">
                      <div className="market-data-name">{index.name}</div>
                      <div className="market-data-value">{index.value.toLocaleString('tr-TR')}</div>
                      <div className={`market-data-change ${index.change >= 0 ? 'positive' : 'negative'}`}>
                        {index.change >= 0 ? '+' : ''}{index.change}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="dashboard-card">
                <h3>Döviz Kurları</h3>
                <div className="market-data-list">
                  {marketData.currencies.map((currency, i) => (
                    <div key={i} className="market-data-item">
                      <div className="market-data-name">{currency.name}</div>
                      <div className="market-data-value">{currency.value.toLocaleString('tr-TR')}</div>
                      <div className={`market-data-change ${currency.change >= 0 ? 'positive' : 'negative'}`}>
                        {currency.change >= 0 ? '+' : ''}{currency.change}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="dashboard-card">
                <h3>Emtialar</h3>
                <div className="market-data-list">
                  {marketData.commodities.map((commodity, i) => (
                    <div key={i} className="market-data-item">
                      <div className="market-data-name">{commodity.name}</div>
                      <div className="market-data-value">{commodity.value.toLocaleString('tr-TR')}</div>
                      <div className={`market-data-change ${commodity.change >= 0 ? 'positive' : 'negative'}`}>
                        {commodity.change >= 0 ? '+' : ''}{commodity.change}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'ai-performance':
        return (
          <div className="ai-performance-overview">
            <div className="overview-header">
              <h2>AI Önerileri Performansı</h2>
              <div className="overview-value">
                <span className="value">{aiRecommendationsData.totalCurrentValue.toLocaleString('tr-TR')} TL</span>
                <span className={`change ${aiRecommendationsData.overallPerformance >= 0 ? 'positive' : 'negative'}`}>
                  {aiRecommendationsData.overallPerformance >= 0 ? '+' : ''}{aiRecommendationsData.overallPerformance}%
                </span>
              </div>
            </div>
            
            <div className="dashboard-stats-row">
              <div className="stat-box">
                <div className="stat-title">Toplam Yatırım</div>
                <div className="stat-value">{aiRecommendationsData.totalInvestmentAmount.toLocaleString('tr-TR')} TL</div>
              </div>
              <div className="stat-box">
                <div className="stat-title">Güncel Değer</div>
                <div className="stat-value">{aiRecommendationsData.totalCurrentValue.toLocaleString('tr-TR')} TL</div>
              </div>
              <div className="stat-box">
                <div className="stat-title">Beklenen Getiri</div>
                <div className="stat-value">%{aiRecommendationsData.averageExpectedReturn.toFixed(1)}</div>
              </div>
              <div className="stat-box">
                <div className="stat-title">Gerçekleşen Getiri</div>
                <div className={`stat-value ${aiRecommendationsData.averageActualReturn >= aiRecommendationsData.averageExpectedReturn ? 'positive' : 'negative'}`}>
                  %{aiRecommendationsData.averageActualReturn.toFixed(1)}
                </div>
              </div>
            </div>
            
            <div className="performance-chart-container">
              <h3>Beklenen vs Gerçekleşen Getiri</h3>
              <div className="performance-chart">
                <div className="chart-bars">
                  <div className="chart-label">Beklenen</div>
                  <div className="chart-bar expected" style={{width: `${aiRecommendationsData.averageExpectedReturn * 5}%`}}>
                    %{aiRecommendationsData.averageExpectedReturn.toFixed(1)}
                  </div>
                </div>
                <div className="chart-bars">
                  <div className="chart-label">Gerçekleşen</div>
                  <div className={`chart-bar actual ${aiRecommendationsData.averageActualReturn >= aiRecommendationsData.averageExpectedReturn ? 'positive' : 'negative'}`} 
                       style={{width: `${aiRecommendationsData.averageActualReturn * 5}%`}}>
                    %{aiRecommendationsData.averageActualReturn.toFixed(1)}
                  </div>
                </div>
              </div>
              
              <div className="performance-summary">
                <div className="summary-item">
                  <div className="summary-label">Başarı Oranı:</div>
                  <div className="summary-value">%{aiRecommendationsData.successRate}</div>
                </div>
                <div className="summary-item">
                  <div className="summary-label">En İyi Performans:</div>
                  <div className="summary-value positive">{aiRecommendationsData.bestPerformer.symbol} (%{aiRecommendationsData.bestPerformer.return})</div>
                </div>
                <div className="summary-item">
                  <div className="summary-label">En Düşük Performans:</div>
                  <div className="summary-value negative">{aiRecommendationsData.worstPerformer.symbol} (%{aiRecommendationsData.worstPerformer.return})</div>
                </div>
              </div>
            </div>
            
            <h3>AI Yatırım Önerileri Detayı</h3>
            {aiRecommendationsData.recommendations.map((recommendation) => (
              <div key={recommendation.id} className="recommendation-card">
                <div className="recommendation-header">
                  <div className="recommendation-title">
                    <span className="recommendation-date">{new Date(recommendation.date).toLocaleDateString('tr-TR')}</span>
                    <span className="recommendation-amount">{recommendation.initialInvestment.toLocaleString('tr-TR')} TL</span>
                  </div>
                  <div className={`recommendation-performance ${recommendation.status}`}>
                    <div className="performance-label">Performans Farkı:</div>
                    <div className="performance-value">
                      {recommendation.performanceDifference >= 0 ? '+' : ''}{recommendation.performanceDifference}%
                    </div>
                  </div>
                </div>
                
                <div className="recommendation-assets">
                  <table className="assets-table">
                    <thead>
                      <tr>
                        <th>Varlık</th>
                        <th>Dağılım</th>
                        <th>Beklenen</th>
                        <th>Gerçekleşen</th>
                        <th>Fark</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recommendation.assets.map((asset, index) => (
                        <tr key={index}>
                          <td><strong>{asset.symbol}</strong> - {asset.name}</td>
                          <td>%{asset.allocation}</td>
                          <td>%{asset.expectedReturn}</td>
                          <td>%{asset.actualReturn}</td>
                          <td className={asset.actualReturn >= asset.expectedReturn ? 'positive' : 'negative'}>
                            {asset.actualReturn >= asset.expectedReturn ? '+' : ''}{(asset.actualReturn - asset.expectedReturn).toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div className="recommendation-summary">
                  <div className="summary-row">
                    <div className="summary-column">
                      <div className="summary-item">
                        <div className="summary-label">Yatırım Tutarı:</div>
                        <div className="summary-value">{recommendation.initialInvestment.toLocaleString('tr-TR')} TL</div>
                      </div>
                      <div className="summary-item">
                        <div className="summary-label">Güncel Değer:</div>
                        <div className="summary-value">{recommendation.currentValue.toLocaleString('tr-TR')} TL</div>
                      </div>
                    </div>
                    <div className="summary-column">
                      <div className="summary-item">
                        <div className="summary-label">Beklenen Getiri:</div>
                        <div className="summary-value">%{recommendation.expectedReturnTotal}</div>
                      </div>
                      <div className="summary-item">
                        <div className="summary-label">Gerçekleşen Getiri:</div>
                        <div className={`summary-value ${recommendation.actualReturnTotal >= recommendation.expectedReturnTotal ? 'positive' : 'negative'}`}>
                          %{recommendation.actualReturnTotal}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="recommendation-notes">
                    <div className="notes-label">AI Notları:</div>
                    <div className="notes-content">{recommendation.notes}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      
      default:
        return <div>Tab içeriği bulunamadı</div>;
    }
  };
  
  return (
    <div className="dashboard-page">
      <NavBar />
      <div className="navbar-spacer"></div>
      
      {/* Galaxy background overlay */}
      <div className="animated-background">
        <div className="gradient-overlay"></div>
        <div className="stars-overlay"></div>
        <div className="floating-particles"></div>
      </div>
      
      <div className="dashboard-container">
        <div className="dashboard-header">
          <h1>Yatırım Paneli</h1>
          <div className="tabs">
            <button 
              className={`tab ${activeTab === 'accounts' ? 'active' : ''}`}
              onClick={() => setActiveTab('accounts')}
            >
              Hesaplar
            </button>
            <button 
              className={`tab ${activeTab === 'portfolio' ? 'active' : ''}`}
              onClick={() => setActiveTab('portfolio')}
            >
              Portföy
            </button>
            <button 
              className={`tab ${activeTab === 'ai-performance' ? 'active' : ''}`}
              onClick={() => setActiveTab('ai-performance')}
            >
              AI Performansı
            </button>
            <button 
              className={`tab ${activeTab === 'market' ? 'active' : ''}`}
              onClick={() => setActiveTab('market')}
            >
              Piyasa
            </button>
          </div>
        </div>
        
        <div className="dashboard-content">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;


