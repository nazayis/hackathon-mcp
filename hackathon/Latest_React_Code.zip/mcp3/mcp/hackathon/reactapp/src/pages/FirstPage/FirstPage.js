import React from "react";
import { useNavigate } from "react-router-dom";
import NavBar from '../../components/NavBar/NavBar';
import './FirstPage.css';

function FirstPage() {
  const navigate = useNavigate();

  return (
    <div className="first-page-wrapper">
      <NavBar />
      <div className="navbar-spacer"></div>
      <div className="home-container">
        <h1>Hoşgeldiniz</h1>
        <p>Burası ilk sayfa. Lütfen bir sayfa seçin:</p>
        <div className="button-group">
          <button onClick={() => navigate("/newUser")}>Yeni Kullanıcı</button>
          <button onClick={() => navigate("/homePage")}>Düzenli Kullanıcı</button>
          <button onClick={() => navigate("/portfolio")}>Portföy Asistanı</button>
        </div>
      </div>
    </div>
  );
}

export default FirstPage;
