import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './index.css';
import App from './App';

// Prevent MetaMask errors by patching window.ethereum
if (typeof window !== 'undefined') {
  // Handle potential MetaMask connection errors
  const originalEthereum = window.ethereum;
  
  // Create a wrapper that handles connection failures gracefully
  if (originalEthereum) {
    const originalRequest = originalEthereum.request;
    
    if (originalRequest) {
      originalEthereum.request = async (...args) => {
        try {
          return await originalRequest.apply(originalEthereum, args);
        } catch (error) {
          console.log("Ethereum request error handled:", error);
          return null;
        }
      };
    }
  }
  
  // Add a simple implementation for environments without MetaMask
  if (!window.ethereum) {
    window.ethereum = {
      isMetaMask: false,
      request: async () => {
        console.log("MetaMask not available - request ignored");
        return null;
      },
      on: () => {},
      removeListener: () => {},
      autoRefreshOnNetworkChange: false,
    };
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
