import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './NavBar.css';

const NavBar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  return (
    <div className="navbar">
      <div className="navbar-left">
        <div className="logo" onClick={() => navigate('/')}>
          <span className="logo-icon">📊</span>
          <span className="logo-text">Fibabanka</span>
        </div>
      </div>
      <div className="navbar-right">
        <button 
          className={`dashboard-link ${location.pathname === '/dashboard' ? 'active' : ''}`}
          onClick={() => navigate('/dashboard')}
        >
          Dashboard
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
            <path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z" fill="currentColor"/>
          </svg>
        </button>
      </div>
    </div>
  );
};

export default NavBar;
