# agent.py

from typing import List, Optional, Dict
import asyncio
from pathlib import Path
from textwrap import dedent
import os
from dotenv import load_dotenv


# Load environment variables from .env file
load_dotenv()

# Validate API keys
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise ValueError(
        "GOOGLE_API_KEY not found in environment variables. "
        "Please add it to your .env file. "
        "Get your key from: https://aistudio.google.com/app/apikey"
    )

print(f"Google API key loaded: {GOOGLE_API_KEY[:10]}..." if len(GOOGLE_API_KEY) > 10 else "Invalid key")

# --- Agno Kütüphaneleri ---
from agno.agent import Agent
from agno.models.google import Gemini
from agno.team import Team

# --- Araç Setleri (Tools) ---
from agno.tools.yfinance import YFinanceTools
from agno.tools.googlesearch import GoogleSearchTools
from agno.tools.reasoning import ReasoningTools
from agno.tools.mcp import MCPTools 
# Bu araçların projenizde 'tools/' klasörü altında olduğunu varsayıyoruz.
# Eğer değillerse, lütfen bu importları kendi projenize göre düzenleyin.
# from tools.mock_bank_data import MockBankDataTools
# from tools.money_transfer import MoneyTransferTools

# --- Bilgi Bankası (Knowledge Base) ve Veritabanı (Vector DB) ---
from agno.knowledge.markdown import MarkdownKnowledgeBase
from agno.vectordb.lancedb import LanceDb

# --- Hafıza Yönetimi (Memory Management) ---
from agno.memory.v2 import Memory, MemoryManager
from agno.memory.v2.db.sqlite import SqliteMemoryDb

# --- Proje Konfigürasyonu ---
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)
RISKOMETRE_PDF_DIR = Path(__file__).parent / "riskometre"
RISKOMETRE_PDF_DIR.mkdir(exist_ok=True)


# --- Bilgi Bankası ve Vektör Veritabanı Kurulumu ---
LANCEDB_URI = OUTPUT_DIR / "vector_db"

try:
    from agno.vectordb.lancedb import LanceDb
    
    riskometre_vector_db = LanceDb(
        table_name="fibabanka_riskometre",
        uri=LANCEDB_URI,
    )
    
    riskometre_kb = MarkdownKnowledgeBase(
        path=RISKOMETRE_PDF_DIR,
        vector_db=riskometre_vector_db,
    )
    print("Vector search enabled")
    
except ImportError as e:
    print(f"Vector search not available: {e}")
    print("Using simple knowledge base without vector search")
    
    # Simple knowledge base without vector search
    class SimpleKnowledgeBase:
        def __init__(self, path):
            self.path = Path(path)
            self.documents = []
        
        def load(self, recreate=False):
            print("Simple knowledge base loaded (no vector search)")
    
    riskometre_kb = SimpleKnowledgeBase(RISKOMETRE_PDF_DIR)

except Exception as e:
    print(f"Failed to initialize vector database: {e}")
    print("Using minimal knowledge base")
    
    class MinimalKB:
        def __init__(self, path):
            self.path = path
        def load(self, recreate=False):
            print("Minimal knowledge base loaded")
    
    riskometre_kb = MinimalKB(RISKOMETRE_PDF_DIR)

# --- Hafıza Yapılandırması ---
USER_MEMORY_DB_FILE = OUTPUT_DIR / "memory/user_portfolio_memory.db"
USER_MEMORY_DB_FILE.parent.mkdir(parents=True, exist_ok=True)
user_memory_db = SqliteMemoryDb(table_name="user_memories", db_file=str(USER_MEMORY_DB_FILE))

capture_instructions = dedent("""
    Senin görevin, konuşmadan sadece en değerli ve nihai çıktıları yakalamaktır.
    - KAYDEDİLECEKLER:
      1. Kullanıcının risk profili (konservatif, ılımlı, agresif).
      2. Kullanıcının belirttiği yatırım hedefleri (örn: "uzun vadeli büyüme", "düşük riskli getiri").
      3. Onaylanan nihai alım/satım işlemleri ve portföy planları.
    - GÖRMEZDEN GELİNECEKLER:
      - Ara hesaplamaları, ham piyasa verilerini, URL listelerini veya işlenmemiş diğer verileri kaydetme.
      - Amacın, gelecekte başvurulabilecek rafine ve nihai bilgileri saklamaktır.
""")

memory_manager = MemoryManager(memory_capture_instructions=capture_instructions)


# Import our new MCP manager
from mcp_manager import get_mcp_manager

async def run_portfolio_interaction(user_id: str, session_id: str, user_message: str) -> str:
    """
    Kullanıcı arayüzü tarafından çağrılacak ana giriş noktası.
    """
    print(f"Starting portfolio interaction for user: {user_id}, session: {session_id}")
    print(f"User message: {user_message}")

    try:
        # Get the MCP manager instance
        mcp_manager = await get_mcp_manager()
        mcp_database_tools = await mcp_manager.get_tools()

        if not mcp_database_tools:
            print("MCP tools are not available. Running in fallback mode.")
            # Create portfolio team without MCP tools
            portfolio_team = _create_portfolio_team_structure(
                user_id=user_id,
                session_id=session_id,
                mcp_tool_instance=None
            )
        else:
            # Create portfolio team with MCP tools
            portfolio_team = _create_portfolio_team_structure(
                user_id=user_id,
                session_id=session_id,
                mcp_tool_instance=mcp_database_tools
            )

        print("Running portfolio team...")
        response = await portfolio_team.arun(message=user_message)
        print(f"Team response: {response}")

        if hasattr(response, 'content'):
            return response.content
        else:
            return str(response) if response else "I processed your request but couldn't generate a proper response."

    except Exception as e:
        print(f"An error occurred during portfolio interaction: {e}")
        import traceback
        traceback.print_exc()
        return f"I'm experiencing technical difficulties. Please try again later. Error: {str(e)}"

# --- Bilgi Bankası ve Vektör Veritabanı Kurulumu ---
LANCEDB_URI = OUTPUT_DIR / "vector_db"

try:
    from agno.vectordb.lancedb import LanceDb
    
    riskometre_vector_db = LanceDb(
        table_name="fibabanka_riskometre",
        uri=LANCEDB_URI,
    )
    
    riskometre_kb = MarkdownKnowledgeBase(
        path=RISKOMETRE_PDF_DIR,
        vector_db=riskometre_vector_db,
    )
    print("Vector search enabled")
    
except ImportError as e:
    print(f"Vector search not available: {e}")
    print("Using simple knowledge base without vector search")
    
    # Simple knowledge base without vector search
    class SimpleKnowledgeBase:
        def __init__(self, path):
            self.path = Path(path)
            self.documents = []
        
        def load(self, recreate=False):
            print("Simple knowledge base loaded (no vector search)")
    
    riskometre_kb = SimpleKnowledgeBase(RISKOMETRE_PDF_DIR)

except Exception as e:
    print(f"Failed to initialize vector database: {e}")
    print("Using minimal knowledge base")
    
    class MinimalKB:
        def __init__(self, path):
            self.path = path
        def load(self, recreate=False):
            print("Minimal knowledge base loaded")
    
    riskometre_kb = MinimalKB(RISKOMETRE_PDF_DIR)

# --- Hafıza Yapılandırması ---
USER_MEMORY_DB_FILE = OUTPUT_DIR / "memory/user_portfolio_memory.db"
USER_MEMORY_DB_FILE.parent.mkdir(parents=True, exist_ok=True)
user_memory_db = SqliteMemoryDb(table_name="user_memories", db_file=str(USER_MEMORY_DB_FILE))

capture_instructions = dedent("""
    Senin görevin, konuşmadan sadece en değerli ve nihai çıktıları yakalamaktır.
    - KAYDEDİLECEKLER:
      1. Kullanıcının risk profili (konservatif, ılımlı, agresif).
      2. Kullanıcının belirttiği yatırım hedefleri (örn: "uzun vadeli büyüme", "düşük riskli getiri").
      3. Onaylanan nihai alım/satım işlemleri ve portföy planları.
    - GÖRMEZDEN GELİNECEKLER:
      - Ara hesaplamaları, ham piyasa verilerini, URL listelerini veya işlenmemiş diğer verileri kaydetme.
      - Amacın, gelecekte başvurulabilecek rafine ve nihai bilgileri saklamaktır.
""")

memory_manager = MemoryManager(memory_capture_instructions=capture_instructions)


async def run_portfolio_interaction(user_id: str, session_id: str, user_message: str) -> str:
    """
    Kullanıcı arayüzü tarafından çağrılacak ana giriş noktası.
    """
    print(f"Starting portfolio interaction for user: {user_id}, session: {session_id}")
    print(f"User message: {user_message}")

    try:
        # Get the MCP manager instance
        mcp_manager = await get_mcp_manager()
        mcp_database_tools = await mcp_manager.get_tools()

        if not mcp_database_tools:
            print("MCP tools are not available. Running in fallback mode.")
            # Create portfolio team without MCP tools
            portfolio_team = _create_portfolio_team_structure(
                user_id=user_id,
                session_id=session_id,
                mcp_tool_instance=None
            )
        else:
            # Create portfolio team with MCP tools
            portfolio_team = _create_portfolio_team_structure(
                user_id=user_id,
                session_id=session_id,
                mcp_tool_instance=mcp_database_tools
            )

        print("Running portfolio team...")
        response = await portfolio_team.arun(message=user_message)
        print(f"Team response: {response}")

        if hasattr(response, 'content'):
            return response.content
        else:
            return str(response) if response else "I processed your request but couldn't generate a proper response."

    except Exception as e:
        print(f"An error occurred during portfolio interaction: {e}")
        import traceback
        traceback.print_exc()
        return f"I'm experiencing technical difficulties. Please try again later. Error: {str(e)}"

def _create_portfolio_team_structure(
    user_id: str, session_id: str, mcp_tool_instance: MCPTools
) -> Team:
    """
    Portföy yönetimi için ajan takımının ve üyelerinin yapısal tanımını oluşturur.
    MCP aracı gibi dinamik kaynaklar bu fonksiyona dışarıdan parametre olarak verilir.
    """
    memory_instance = Memory(db=user_memory_db, memory_manager=memory_manager)

    analyzer_agent = Agent(
        name="AnalyzerAgent",
        role="Kullanıcının mevcut finansal durumunu analiz eder ve veritabanı sorguları yapar.",
        model=Gemini(id="gemini-1.5-flash"),
        instructions=[
            "Sen bir finansal analiz uzmanısın.",
            "Görevin, kullanıcının farklı bankalardaki varlıklarını, mevcut portföyünü ve veritabanındaki diğer finansal verilerini bütünsel olarak analiz etmektir.",
            # "1. `MockBankDataTools`'un `get_all_accounts` fonksiyonunu kullanarak 'NAZ AYIS' adlı kullanıcının tüm bankalardaki (Fibabanka, İş Bankası, Garanti) hesap bilgilerini çek.",
            "2. `YFinanceTools` kullanarak portföydeki hisse senedi, fon gibi varlıkların anlık piyasa değerlerini bul.",
            "3. Topladığın verileri birleştirerek net ve anlaşılır bir portföy özeti (JSON formatında) oluştur. Bu özet şunları içermeli: toplam varlık, bankalara göre dağılım, varlık türüne göre dağılım (nakit, hisse, fon).",
            # "4. Bir para transferi talebi geldiğinde, 'transfer_funds' aracını kullanarak işlemi gerçekleştir.",
            "5. **ÖNEMLİ:** Doğrudan veritabanı sorgusu gerektiren (örn: 'geçmiş işlem dökümü', 'kredi skoru bilgisi' gibi) talepler için, sana sağlanan `mcp_server` araçlarını kullan.",
        ],
        # MCP aracı ve diğer statik araçlar burada tanımlanır.
        tools=[mcp_tool_instance, YFinanceTools(), GoogleSearchTools()],
        monitoring=True,
    )

    risk_profiler_agent = Agent(
        name="RiskProfilerAgent",
        role="Kullanıcının risk iştahını ve piyasanın risk durumunu belirler.",
        model=Gemini(id="gemini-1.5-flash"),
        instructions=[
            "Sen bir risk yönetimi uzmanısın.",
            "Sana Bilgi Bankası'ndan (Knowledge Base) sağlanan güncel Riskometre verilerini analiz et.",
            "Bu verilere dayanarak piyasanın genel risk durumunu (BIST100, Teknoloji, Bankacılık vb. için) yapısal bir formatta (JSON) özetle.",
            "Ayrıca kullanıcının geçmiş tercihlerini (hafızadan) analiz ederek kişisel risk profilini (konservatif, ılımlı, agresif) belirle.",
        ],
        tools=[],
        monitoring=True,
    )

    portfolio_builder_agent = Agent(
        name="PortfolioBuilderAgent",
        role="Yeni yatırım stratejileri ve portföy sepetleri oluşturur.",
        model=Gemini(id="gemini-1.5-flash"),
        instructions=[
            "Sen bir portföy yöneticisisin.",
            "Görevin, sıfırdan veya yeni bir nakit girişiyle yatırım sepeti önerileri oluşturmaktır.",
            "1. `RiskProfilerAgent`'tan gelen kullanıcı risk profili ve piyasa risk değerlendirmesini dikkate al.",
            "2. `YFinanceTools` ve `GoogleSearchTools` kullanarak risk profiline uygun potansiyel yatırım araçlarını (fon, hisse senedi vb.) araştır.",
            "3. Kullanıcının yatırım tutarını ve hedefini göz önünde bulundurarak, çeşitlendirilmiş ve gerekçelendirilmiş bir alım listesi (JSON formatında) oluştur. Her önerinin nedenini kısaca açıkla (örn: 'Teknoloji sektörü düşük riskli olduğu ve büyüme potansiyeli taşıdığı için X teknoloji fonu').",
        ],
        tools=[YFinanceTools(), GoogleSearchTools(), ReasoningTools()],
        monitoring=True,
    )

    rebalance_agent = Agent(
        name="RebalanceAgent",
        role="Mevcut portföyü piyasa koşullarına ve risk profiline göre yeniden dengeler.",
        model=Gemini(id="gemini-1.5-flash"),
        instructions=[
            "Sen bir portföy optimizasyon uzmanısın.",
            "Görevin, değişen piyasa koşullarına göre mevcut portföy için alım/satım önerileri sunmaktır.",
            "1. `AnalyzerAgent`'tan gelen güncel portföy durumunu ve `RiskProfilerAgent`'tan gelen yeni piyasa risk değerlendirmesini al.",
            "2. Portföydeki varlıkların risk seviyeleri ile güncel piyasa riskleri arasında bir uyumsuzluk var mı kontrol et. (Örn: Portföyde yüksek oranda 'Bankacılık' hissesi varken, piyasa riski bu sektörü 'riskli' olarak işaretlemişse bu bir uyumsuzluktur).",
            "3. Uyumsuzluk varsa, portföyü tekrar kullanıcının risk profiline uygun hale getirecek alım/satım işlemleri (JSON formatında) öner. Önerilerin net, uygulanabilir ve gerekçeli olmalı.",
        ],
        tools=[YFinanceTools(), GoogleSearchTools(), ReasoningTools()],
        monitoring=True,
    )

    team_instructions = dedent(f"""
        Sen, uzman finansal ajanlardan oluşan bir takımı yöneten kıdemli bir Portföy Yöneticisisin. Amacın, kullanıcı taleplerini ve piyasa verilerini analiz ederek akıllı ve kişiselleştirilmiş yatırım tavsiyeleri sunmaktır.

        **ÖNCELİKLİ GÖREVİN:** Herhangi bir yatırım tavsiyesi vermeden önce, en güncel piyasa risk durumunu öğrenmek için **Bilgi Bankası'nda (Knowledge Base) arama yapmalısın**. "Riskometre piyasa özeti", "BIST100 risk durumu" gibi bir arama sorgusu kullan.

        **SÜREÇ AKIŞI:**
        Kullanıcının mesajını analiz et ve aşağıdaki iş akışlarından uygun olanı seç:

        1. Analiz ve Veritabanı Sorgu Talebi ("portföyümü analiz et", "geçmiş işlemlerimi listele"):
            - `AnalyzerAgent`'ı çağırarak kullanıcının talebini yerine getirmesini iste. Bu ajan hem banka hesaplarını hem de **mcp_server aracılığıyla veritabanını** sorgulayabilir.
            - Raporu kullanıcıya anlaşılır bir dilde özetle.

        2. Yeni Yatırım Talebi ("... TL yatırım yapmak istiyorum", "paramı değerlendir"):
            - Adım 2.1: Bilgi Bankası'ndan en güncel Riskometre verilerini ara ve bul.
            - Adım 2.2: `RiskProfilerAgent`'ı çağır. Ona, Bilgi Bankası'ndan aldığın güncel piyasa riskini vererek bir değerlendirme yapmasını iste.
            - Adım 2.3: `PortfolioBuilderAgent`'ı çağır. Ona, kullanıcıdan gelen yatırım tutarını, hedefini ve bir önceki adımda elde edilen risk profili/piyasa bilgisini ver. Uygun bir yatırım sepeti önermesini iste.
            - Adım 2.4: `PortfolioBuilderAgent`'tan gelen öneriyi kullanıcıya sun ve onayını iste. Planın gerekçelerini vurgula.
        
        3. Periyodik Kontrol veya Yeniden Dengeleme Talebi ("portföyümü kontrol et", "riskler değişti mi?"):
            - Adım 3.1: `AnalyzerAgent`'ı çağırarak mevcut portföy dökümünü al.
            - Adım 3.2: Bilgi Bankası'ndan en güncel Riskometre verilerini ara.
            - Adım 3.3: `RiskProfilerAgent`'ı çağırarak yeni piyasa riskini değerlendir.
            - Adım 3.4: `RebalanceAgent`'ı çağır. Ona mevcut portföyü ve yeni piyasa riskini vererek bir yeniden dengeleme önerisi oluşturmasını iste. Eğer dengeleme gerekmiyorsa bunu belirtmesini iste.
            - Adım 3.5: `RebalanceAgent`'tan gelen öneriyi veya "dengede" bilgisini kullanıcıya sun.

        **Genel Kurallar:**
        - Her zaman kullanıcı onayı olmadan işlem yapma.
        - Ajanlardan gelen JSON çıktılarını yorumlayarak kullanıcıya doğal dilde, net ve aksiyona dönük cevaplar ver.
    """)
    
    portfolio_team = Team(
        name="PortfolioManager",
        mode="coordinate",
        model=Gemini(id="gemini-1.5-flash"),
        members=[analyzer_agent, risk_profiler_agent, portfolio_builder_agent, rebalance_agent],
        tools=[], 
        knowledge=riskometre_kb,
        search_knowledge=True,
        memory=memory_instance,
        enable_user_memories=True,
        add_history_to_messages=True, 
        enable_team_history=True,
        user_id=user_id,
        session_id=session_id,
        description="Kullanıcıların yatırım kararlarına yardımcı olan akıllı bir portföy yönetim takımı.",
        instructions=team_instructions,
        add_datetime_to_instructions=True,
        markdown=True,
        debug_mode=True,
    )

    return portfolio_team