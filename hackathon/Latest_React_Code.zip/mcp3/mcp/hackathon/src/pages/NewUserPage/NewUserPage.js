import React from "react";
import './NewUserPage.css';

function NewUserPage() {
  return (
    <div className="NewUserPage">
      <header className="header">Yeni Kullanıcı</header>
      <section className="content">
        <p>Sayfa B için ayrı bir yapı ve stil kullanıldı.</p>
        <ul>
          <li>Madde 1</li>
          <li>Madde 2</li>
        </ul>
      </section>
    </div>
  );
}

export default NewUserPage;
