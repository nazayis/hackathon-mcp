import React from "react";
import './TransferMoney.css';

function TransferMoney() {
  return (
    <div className="TransferMoney">
      <header className="header">Para Transferi</header>
      <section className="content">
        <p>Para Transfer Ekranı</p>
        
      </section>
    </div>
  );
}

export default TransferMoney;