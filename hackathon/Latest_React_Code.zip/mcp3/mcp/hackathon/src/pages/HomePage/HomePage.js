import React from "react";
import './HomePage.css';
import PortfolioDashboard from '../../components/PortfolioDashboard/PortfolioDashboard';


function HomePage() {
  return (
    <div className="HomePage">
      <PortfolioDashboard />

    </div>
  );
}

export default HomePage;
