import subprocess
import sys
import os
from pathlib import Path

def check_dependencies():
    """Check if required dependencies are installed"""
    required_packages = ["fastapi", "uvicorn", "pydantic", "python-dotenv"]
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"Missing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing_packages)
        print("Dependencies installed successfully")

def build_react_app():
    """Build the React application"""
    react_dir = Path(__file__).parent / "reactapp"
    if not react_dir.exists():
        print("React app directory not found - skipping React build")
        return False
    
    # Check if package.json exists in reactapp directory
    package_json = react_dir / "package.json"
    if not package_json.exists():
        print("package.json not found in reactapp directory")
        return False
    
    print("Building React application...")
    try:
        original_dir = os.getcwd()
        os.chdir(react_dir)
        
        # Try different npm command locations
        npm_commands = ["npm", "npm.cmd", str(react_dir / "node_modules" / ".bin" / "npm")]
        npm_cmd = None
        
        for cmd in npm_commands:
            try:
                subprocess.run([cmd, "--version"], capture_output=True, check=True)
                npm_cmd = cmd
                break
            except (subprocess.CalledProcessError, FileNotFoundError):
                continue
        
        if not npm_cmd:
            print("npm not found. Please ensure Node.js is installed and npm is available")
            return False
        
        # Check if node_modules exists, if not run npm install
        node_modules = react_dir / "node_modules"
        if not node_modules.exists():
            print("Installing npm dependencies...")
            subprocess.run([npm_cmd, "install"], check=True)
        
        print("Building React app...")
        subprocess.run([npm_cmd, "run", "build"], check=True)
        
        # Check if build directory was created
        build_dir = react_dir / "build"
        if build_dir.exists():
            print("React app built successfully")
            return True
        else:
            print("Build directory not found after npm build")
            return False
            
    except subprocess.CalledProcessError as e:
        print(f"React build failed: {e}")
        return False
    finally:
        os.chdir(original_dir)

def check_env_file():
    """Check if .env file exists and has required variables"""
    env_file = Path(__file__).parent / ".env"
    env_example = Path(__file__).parent / ".env.example"
    
    if not env_file.exists():
        if env_example.exists():
            print("WARNING: .env file not found")
            print("Please copy .env.example to .env and add your API keys")
            print("Command: copy .env.example .env")
        else:
            print("WARNING: No environment configuration found")
        return False
    
    try:
        with open(env_file, 'r') as f:
            content = f.read()
            if "GOOGLE_API_KEY=" in content and not content.count("GOOGLE_API_KEY=\n"):
                print("Environment file found with API key")
                return True
            else:
                print("WARNING: GOOGLE_API_KEY not set in .env file")
                print("Please add your Google Gemini API key to enable AI features")
                return False
    except Exception as e:
        print(f"Error reading .env file: {e}")
        return False

def main():
    print("Fibabanka Portfolio Assistant Setup")
    print("=" * 50)
    
    # Check environment configuration
    env_configured = check_env_file()
    
    # Check Python dependencies
    check_dependencies()
    
    # Build React app
    react_built = build_react_app()
    
    # Change back to project directory
    os.chdir(Path(__file__).parent)
    
    print("\nConfiguration Status:")
    print(f"Environment file: {'OK' if env_configured else 'Missing/Incomplete'}")
    print(f"React frontend: {'Built' if react_built else 'Not available'}")
    
    if not env_configured:
        print("\nTo enable AI features:")
        print("1. Get Google Gemini API key from: https://aistudio.google.com/app/apikey")
        print("2. Create .env file with: GOOGLE_API_KEY=your_key_here")
    
    print("\nStarting the server...")
    print("API Documentation: http://localhost:8000/docs")
    print("API Health Check: http://localhost:8000/api/check-agent")
    if react_built:
        print("React App: http://localhost:8000")
    else:
        print("Streamlit UI: streamlit run ui.py")
        if Path(__file__).parent.joinpath("reactapp", "package.json").exists():
            print("Note: React app found but build failed. Try: cd reactapp && npm run build")
    print("\n" + "=" * 50)
    
    # Start the server
    try:
        from backend_server import app
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
    except Exception as e:
        print(f"Server startup failed: {e}")

if __name__ == "__main__":
    main()
