# Fibabanka Portfolio Assistant

A comprehensive portfolio management assistant built with AI agents, React frontend, and FastAPI backend.

## Quick Start

### Option 1: Run Both Servers Separately (Recommended for Development)

1. **Start the Backend Server**:
   ```bash
   python start_backend.py
   ```
   This will start the API server on http://localhost:8000

2. **Start the React Development Server** (in a new terminal):
   ```bash
   python start_react.py
   ```
   This will start the React app on http://localhost:3000

### Option 2: Run Full Stack (Production Build)

```bash
python run_server.py
```

## Development URLs

- **React App**: http://localhost:3000 (development)
- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/api/check-agent

## Configuration

1. **Environment Setup**:
   ```bash
   cp .env.example .env
   # Edit .env and add your Google Gemini API key
   ```

2. **Install Dependencies**:
   ```bash
   pip install fastapi uvicorn pydantic python-dotenv agno
   cd reactapp && npm install
   ```

## Troubleshooting

### React Proxy Errors (ECONNREFUSED)

If you see proxy errors when running React:

1. Make sure the backend server is running first:
   ```bash
   python start_backend.py
   ```

2. Then start the React development server:
   ```bash
   python start_react.py
   ```

3. If issues persist, the React app will fall back to demo mode.

### Backend Connection Issues

- Ensure your `.env` file has a valid `GOOGLE_API_KEY`
- Check that port 8000 is not in use by another application
- Verify all Python dependencies are installed

## API Endpoints

- `GET /api/check-agent` - Check AI agent availability
- `POST /api/portfolio-interaction` - Send messages to the portfolio assistant
- `GET /docs` - Interactive API documentation

## Features

- **Real-time Chat**: Interactive chat interface with AI portfolio assistant
- **Beautiful UI**: Modern, responsive design with glass morphism effects
- **AI-Powered**: Uses Google Gemini for intelligent investment advice
- **Multi-Agent System**: Specialized agents for different portfolio management tasks
- **Fallback Support**: Works in demo mode when backend is unavailable

---

For more information, see the full documentation in this README.
