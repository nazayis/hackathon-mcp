import asyncio
from agno.tools.mcp import MCPTools

class MCPManager:
    """
    A singleton class to manage the lifecycle of the MCPTools instance.
    This prevents creating a new subprocess for every API request.
    """
    _instance = None
    _lock = asyncio.Lock()

    def __init__(self):
        # This should not be called directly. Use get_instance().
        self.mcp_tools = None
        self.mcp_context = None

    @classmethod
    async def get_instance(cls):
        """
        Get the singleton instance of the MCPManager, creating it if necessary.
        """
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
                    await cls._instance._initialize()
        return cls._instance

    async def _initialize(self):
        """
        Initializes the MCPTools instance and enters its async context.
        """
        print("Initializing MCPManager and starting MCPTools subprocess...")
        mcp_server_command = "fastmcp run mcp_server.py"
        self.mcp_tools = MCPTools(mcp_server_command, timeout_seconds=120)
        try:
            # Manually enter the async context
            self.mcp_context = await self.mcp_tools.__aenter__()
            print("MCPTools context entered successfully.")
        except Exception as e:
            print(f"Failed to initialize MCPTools: {e}")
            self.mcp_tools = None
            self.mcp_context = None

    async def get_tools(self):
        """
        Returns the active MCPTools instance.
        """
        if not self.mcp_context:
            print("MCP Tools not available or failed to initialize.")
            return None
        return self.mcp_tools

    async def close(self):
        """
        Gracefully exits the MCPTools async context.
        """
        if self.mcp_context:
            print("Closing MCPTools context...")
            try:
                await self.mcp_tools.__aexit__(None, None, None)
                print("MCPTools context closed successfully.")
            except Exception as e:
                print(f"Error closing MCPTools: {e}")
        self.__class__._instance = None

# Global accessor
async def get_mcp_manager():
    return await MCPManager.get_instance()
