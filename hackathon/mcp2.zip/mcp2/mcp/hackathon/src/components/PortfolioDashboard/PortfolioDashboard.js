// ./src/components/PortfolioDashboard/PortfolioDashboard.js

import fibabankaLogo from '../../assets/fibabanka.png';
import garantiLogo from '../../assets/garanti.png';
import ziraatLogo from '../../assets/ziraat.png';
import { useNavigate } from "react-router-dom";

import React, { useEffect, useState } from 'react';
import { Line } from 'react-chartjs-2';
import 'chart.js/auto';
import './PortfolioDashboard.css';

const PortfolioDashboard = () => {
  const [chartData, setChartData] = useState(null);
  const [assets, setAssets] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [topInvestments, setTopInvestments] = useState([]);
  const [news, setNews] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setChartData({
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [
        {
          label: 'Balance',
          data: [1200, 1250, 1100, 1300, 1450, 1400, 1500],
          borderColor: '#facc15',
          backgroundColor: 'transparent',
        },
      ],
    });

    setAssets([
      { coin: 'BTC', price: 45000, change: -2.5 },
      { coin: 'ETH', price: 3100, change: 1.2 },
    ]);

    setAccounts([
      { bank: 'Fibabanka', amount: 12500, image: fibabankaLogo },
      { bank: 'Garanti Bankası', amount: 3000, image: garantiLogo },
      { bank: 'Ziraat Bankası', amount: 15000, image: ziraatLogo },
    ]);

    setTopInvestments([
      { name: 'SOL', type: 'gainer', percent: 12.3 },
      { name: 'LUNA', type: 'loser', percent: -8.5 },
    ]);

    setNews([
      'Bitcoin 50.000$ seviyesine yaklaştı.',
      'Ethereum Merge sonrası yeni zirve yaptı.',
      'FED faiz kararını açıkladı.',
      'Altcoin sezonu kapıda olabilir.',
    ]);
  }, []);

  return (
    <div className="dashboard-container-wrapper">
      <div className="dashboard-container">
        <div className="card chart">
          <h2>Estimated Balance</h2>
          {chartData && <Line data={chartData} />}
        </div>

        <div className="card accounts">
          <h2>Accounts</h2>
          <div className="accounts-list">
            {accounts.map((acc, idx) => (
              <div key={idx} className="account-card">
                <img src={acc.image} alt={acc.bank} className="bank-logo" />
                <div className="account-details">
                  <span className="account-bank">{acc.bank}</span>
                  <span className="account-amount">{acc.amount.toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}</span>
                  <div className="button-group">
                    <button className="trade-button" onClick={() => navigate("/TransferMoney")}>Para Yatır</button>
                    <button className="trade-button" onClick={() => navigate("/TransferMoney")}>Para Aktar</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card assets">
          <h2>My Assets</h2>
          <table>
            <thead>
              <tr>
                <th>Coin</th>
                <th>Price</th>
                <th>Change</th>
              </tr>
            </thead>
            <tbody>
              {assets.map((a, i) => (
                <tr key={i} className={a.change >= 0 ? 'positive' : 'negative'}>
                  <td>{a.coin}</td>
                  <td>${a.price.toLocaleString()}</td>
                  <td>{a.change}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card investments">
          <h2>Top Investments</h2>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Type</th>
                <th>Change</th>
              </tr>
            </thead>
            <tbody>
              {topInvestments.map((inv, i) => (
                <tr key={i} className={inv.percent >= 0 ? 'positive' : 'negative'}>
                  <td>{inv.name}</td>
                  <td>{inv.type}</td>
                  <td>{inv.percent}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="news-ticker">
        <div className="ticker-content">
          {news.map((n, idx) => (
            <span key={idx} className="news-item">🔔 {n}</span>
          ))}
        </div>
      </div>
      <a
        href="https://www.trendyol.com/"
        target="_blank"
        rel="noopener noreferrer"
        className="trendyol-button"
      >
        🛒
      </a>
    </div>
  );
};

export default PortfolioDashboard;
