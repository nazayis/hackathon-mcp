import React from "react";
import { useNavigate } from "react-router-dom";
import './FirstPage.css';

function FirstPage() {
  const navigate = useNavigate();

  return (
    <div className="home-container">
      <h1>Hoşgeldiniz</h1>
      <p>Burası ilk sayfa. Lütfen bir sayfa seçin:</p>
      <div className="button-group">
        <button onClick={() => navigate("/newUser")}>Yeni Kullanıcı</button>
        <button onClick={() => navigate("/homePage")}>Düzenli Kullanıcı</button>
      </div>
    </div>
  );
}

export default FirstPage;