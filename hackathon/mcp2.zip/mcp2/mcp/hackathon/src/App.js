// src/App.js
import React from "react";
import { Routes, Route } from "react-router-dom";
import FirstPage from "./pages/FirstPage/FirstPage";
import HomePage from "./pages/HomePage/HomePage";
import NewUserPage from "./pages/NewUserPage/NewUserPage";
import TransferMoney from "./pages/TransferMoney/TransferMoney";

function App() {
  return (
    <Routes>
      <Route path="/" element={<FirstPage />} />
      <Route path="/newUser" element={<NewUserPage />} />
      <Route path="/homePage" element={<HomePage />} />
      <Route path ="/transferMoney" element={<TransferMoney />} />
    </Routes>
  );
}

export default App;
