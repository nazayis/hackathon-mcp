# ui.py

import streamlit as st
from dotenv import load_dotenv
import asyncio
import uuid

# Ortam değişkenlerini yükle
load_dotenv()

# --- 1. SAYFA YAPILANDIRMASI ---
st.set_page_config(layout="wide", page_title="Fibabanka Portföy Asistanı")

# --- Ajan Mantığının İçe Aktarılması ---
try:
    # --- DEĞİŞTİRİLDİ: Yeni ana fonksiyonumuzu içe aktarıyoruz ---
    from agent import run_portfolio_interaction, riskometre_kb
except ImportError as e:
    st.error(f"Ajan mantığı 'agent.py' dosyasından içe aktarılamadı: {e}")
    st.info("Lütfen 'agent.py' dosyasındaki yeni 'run_portfolio_interaction' fonksiyonunu kontrol edin.")
    st.stop()

# --- Asenkron Olay Döngüsü Yönetimi ---
def get_or_create_event_loop():
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop

# --- Bilgi Bankası Yükleme ---
@st.cache_resource
def load_knowledge_base():
    progress_bar = st.progress(0, text="Bilgi Bankası ilk kez yükleniyor...")
    try:
        riskometre_kb.load(recreate=False) 
        progress_bar.progress(100, text="Bilgi Bankası başarıyla yüklendi!")
    except Exception as e:
        progress_bar.empty()
        st.error(f"Bilgi Bankası yüklenirken bir hata oluştu: {e}")
        st.stop()

# --- 2. BİLGİ BANKASI YÜKLEME ---
load_knowledge_base()

# --- 3. SAYFA BAŞLIKLARI VE ARAYÜZ ---
st.title("📈 Fibabanka Portföy Asistanı")
st.caption("Riskometre verileri ve yapay zeka ile yatırımlarınızı yönetin.")

# --- Oturum Durumu (Session State) ---
if "messages" not in st.session_state:
    st.session_state.messages = []
    st.session_state.user_id = "hackathon_user"
    st.session_state.session_id = str(uuid.uuid4())
    st.session_state.messages.append({
        "role": "assistant",
        "content": "Merhaba! Ben Fibabanka Portföy Asistanınız. Yatırımlarınızı yönetmenize nasıl yardımcı olabilirim?"
    })

# --- DEĞİŞTİRİLDİ: Takımı session_state'te saklama kısmı kaldırıldı. ---
# Artık her istekte yeniden oluşturulup çalıştırılacak.

# --- Sohbet Geçmişini Göster ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- Örnek Senaryo Arayüzü ---
# ... (bu kısım aynı kalabilir) ...
if len(st.session_state.messages) == 1:
    st.markdown("---")
    st.write("Yatırım hedefinizi yazarak başlayın veya bir örnek senaryo deneyin:")
    investment_scenario_text = "Merhaba, 55.000 TL yatırım yapmak istiyorum. Mevcut piyasa koşullarına göre ılımlı bir riskle paramı nasıl değerlendirebilirim?"
    if st.button("💰 55.000 TL yatırım senaryosunu dene"):
        # We'll set the prompt directly to be processed below
        st.session_state.prompt_from_button = investment_scenario_text
        st.rerun()


# --- Ana Etkileşim Döngüsü ---

prompt = st.chat_input("Yatırım hedefinizi veya sorunuzu yazın...")

# Check if the button set a prompt
if "prompt_from_button" in st.session_state and st.session_state.prompt_from_button:
    prompt = st.session_state.prompt_from_button
    del st.session_state.prompt_from_button # Clear it after use

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Asistanınız sizin için en iyi yatırım seçeneklerini düşünüyor..."):
            loop = get_or_create_event_loop()
            
            # --- DEĞİŞTİRİLDİ: Doğrudan yeni ana fonksiyonu çağırıyoruz ---
            ai_response = loop.run_until_complete(
                run_portfolio_interaction(
                    user_id=st.session_state.user_id,
                    session_id=st.session_state.session_id,
                    user_message=prompt
                )
            )
            st.markdown(ai_response)
    
    st.session_state.messages.append({"role": "assistant", "content": ai_response})
    st.rerun()