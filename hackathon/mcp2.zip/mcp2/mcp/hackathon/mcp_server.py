# mcp_server.py
from fastmcp import FastMCP

try:
    from banking_api import app as banking_api_app
    
    mcp = FastMCP.from_fastapi(
        app=banking_api_app,
        name="Riskometre Portföy API Sunucusu",
        instructions="Bu sunucu, kullanıcıların banka hesaplarını yönetmek ve para transferi yapmak için araçlar sunar."
    )
    
except ImportError as e:
    print(f"⚠️ Banking API not available: {e}")
    # Create a minimal MCP server
    mcp = FastMCP(
        name="Minimal MCP Server",
        instructions="Minimal MCP server for development"
    )

if __name__ == "__main__":
    mcp.run()