import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import PortfolioAssistant from './components/PortfolioAssistant';
import FirstPage from './pages/FirstPage/FirstPage';
import HomePage from './pages/HomePage/HomePage';
import NewUserPage from './pages/NewUserPage/NewUserPage';
import TransferMoney from './pages/TransferMoney/TransferMoney';
import Dashboard from './pages/Dashboard/Dashboard';
import './App.css';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<FirstPage />} />
        <Route path="/portfolio" element={<PortfolioAssistant />} />
        <Route path="/newUser" element={<NewUserPage />} />
        <Route path="/homePage" element={<HomePage />} />
        <Route path="/transferMoney" element={<TransferMoney />} />
        <Route path="/dashboard" element={<Dashboard />} />
        {/* Redirect any other routes to the home page */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}

export default App;
