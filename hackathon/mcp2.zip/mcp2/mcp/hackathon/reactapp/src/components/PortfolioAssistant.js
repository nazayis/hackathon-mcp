import React, { useState, useEffect, useRef, useCallback } from 'react';
import NavBar from './NavBar/NavBar';
import ReactMarkdown from 'react-markdown';
import './PortfolioAssistant.css';

// API base URL - use absolute URL to avoid proxy issues
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? '' 
  : 'http://localhost:8000';

const PortfolioAssistant = () => {
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [agentAvailable, setAgentAvailable] = useState(true);
  const [userId] = useState('hackathon_user');
  const [sessionId] = useState(() => generateUUID());
  const [isScrolled, setIsScrolled] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const [portfolioData, setPortfolioData] = useState({
    totalValue: 325750.42,
    growth: 2.3,
    allocation: [
      { name: 'Hisse Senetleri', value: 40, color: '#58a7ff' },
      { name: 'Tahvil/Bono', value: 30, color: '#6edaa1' },
      { name: 'Nakit', value: 20, color: '#ffd36a' },
      { name: 'Altın', value: 10, color: '#c991ff' }
    ],
    balanceHistory: [290000, 295000, 305000, 310000, 318000, 320000, 325750],
    // Updated date format for better visual appearance
    dates: ['1 Ocak', '15 Ocak', '1 Şubat', '15 Şubat', '1 Mart', '15 Mart', '1 Nisan']
  });
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  const checkAgentAvailability = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/check-agent`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      setAgentAvailable(data.available);
    } catch (error) {
      console.error('Agent check failed:', error);
      setAgentAvailable(false);
    }
  }, []);

  // Add checkAgentAvailability to the dependency array in useEffect
  useEffect(() => {
    // Initialize with welcome message
    setMessages([{
      role: 'assistant',
      content: 'Merhaba! Ben Fibabanka Portföy Asistanınız. Yatırımlarınızı yönetmenize nasıl yardımcı olabilirim? 🎯',
      timestamp: new Date()
    }]);
    
    // Check agent availability
    checkAgentAvailability();
  }, [checkAgentAvailability]); // Add the missing dependency

  // This function will run only once when the component mounts
  useEffect(() => {
    const initialize = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/check-agent`);
        if (!response.ok) throw new Error('Agent check failed');
        const data = await response.json();
        setAgentAvailable(data.available);
      } catch (error) {
        console.error("Agent check failed, running in offline mode:", error);
        setAgentAvailable(false);
      }
    };

    initialize();

    // Set the initial welcome message
    setMessages([{
      role: 'assistant',
      content: 'Merhaba! Ben Fibabanka Portföy Asistanınız. Yatırımlarınızı yönetmenize nasıl yardımcı olabilirim? 🎯',
      timestamp: new Date()
    }]);

  }, []); // <-- The empty array [] ensures this runs ONLY ONCE.

  useEffect(() => {
    if (autoScroll) {
      scrollToBottom();
    }
  }, [messages, isLoading, autoScroll]);

  useEffect(() => {
    const handleScroll = () => {
      if (messagesContainerRef.current) {
        const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
        const isAtBottom = scrollHeight - scrollTop - clientHeight < 50;
        setIsScrolled(scrollTop > 20);
        
        // Only update autoScroll state when user actively scrolls
        // Don't disable auto-scroll automatically
        if (isAtBottom) {
          setAutoScroll(true);
        }
      }
    };

    const messagesContainer = messagesContainerRef.current;
    if (messagesContainer) {
      messagesContainer.addEventListener('scroll', handleScroll);
      return () => messagesContainer.removeEventListener('scroll', handleScroll);
    }
  }, []);

  // Make scrollToBottom more robust
  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ 
          behavior: "smooth", 
          block: "end"
        });
      }, 100); // Small delay to ensure DOM is updated
    }
  };

  // Manual scroll control button
  const handleManualScroll = () => {
    setAutoScroll(true);
    scrollToBottom();
  };

  function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : ((r & 0x3) | 0x8); // Added parentheses to clarify operations
      return v.toString(16);
    });
  }

  function formatTimestamp(date) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }



  const runPortfolioInteraction = async (userMessage) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/portfolio-interaction`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: userId,
          session_id: sessionId,
          user_message: userMessage
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();
      return data.response;
    } catch (error) {
      console.error('Portfolio interaction failed:', error);
      return mockPortfolioResponse(userMessage);
    }
  };

  const mockPortfolioResponse = (userMessage) => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('55000') || message.includes('55.000')) {
      return `
## 💰 55.000 TL Yatırım Önerisi

Mevcut piyasa koşullarını değerlendirdikten sonra, ılımlı risk profili için aşağıdaki portföy önerisini hazırladım:

### 📊 Önerilen Portföy Dağılımı:
- **%40 (22.000 TL)** - Karma Fonlar (Garanti Portföy Karma Fon gibi)
- **%30 (16.500 TL)** - Devlet Tahvilleri/Eurobond Fonları
- **%20 (11.000 TL)** - BIST 30 Endeks Fonu
- **%10 (5.500 TL)** - Likit fon (acil durum rezervi)

### ✅ Bu önerinin avantajları:
- Diversifikasyon ile risk dağıtımı
- Orta vadeli getiri potansiyeli
- Piyasa dalgalanmalarına karşı koruma
- Likidite esnekliği

⚠️ **Not**: Backend bağlantısı kurulamadı, demo veriler gösteriliyor.`;
    }

    return `
## 🤖 Fibabanka Portföy Asistanı

**Backend Bağlantı Sorunu**: API sunucusuna erişilemiyor.

Lütfen backend sunucusunun çalıştığından emin olun:
\`\`\`bash
python run_server.py
\`\`\`

Demo modunda size yardımcı olabilmek için şu konularda destek verebilirim:
- 💰 Yatırım önerileri ve portföy oluşturma
- 📊 Mevcut portföy analizi
- ⚠️ Risk değerlendirmesi

*Not: Bu bir demo versiyondur.*`;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentMessage.trim()) return;

    const userMessage = currentMessage;
    setCurrentMessage('');
    setIsLoading(true);
    
    // Force auto-scroll to be enabled when sending a new message
    setAutoScroll(true);

    // Add user message
    setMessages(prev => [...prev, { 
      role: 'user', 
      content: userMessage,
      timestamp: new Date()
    }]);

    try {
      const response = await runPortfolioInteraction(userMessage);
      
      // Add assistant response
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: response,
        timestamp: new Date()
      }]);
    } catch (error) {
      console.error('Error:', error);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.',
        timestamp: new Date()
      }]);
    }

    setIsLoading(false);
    // Force a scroll after adding messages
    setTimeout(scrollToBottom, 200);
  };

  const handleExampleScenario = () => {
    const exampleText = "Merhaba, 55.000 TL yatırım yapmak istiyorum. Mevcut piyasa koşullarına göre ılımlı bir riskle paramı nasıl değerlendirebilirim?";
    setCurrentMessage(exampleText);
    
    // Auto-submit after a short delay for better UX
    setTimeout(() => {
      handleSubmit({ preventDefault: () => {} });
    }, 500);
  };

  const renderMessage = (content) => {
    // Add debugging to see what content we're receiving
    console.log('Rendering message content:', content, 'Type:', typeof content);
    
    // Handle null, undefined, or empty content
    if (!content || content === null || content === undefined) {
      console.warn('Empty or null content received');
      return <p>Yanıt alınamadı. Lütfen tekrar deneyin.</p>;
    }
    
    // Ensure content is a string before processing
    const messageContent = typeof content === 'string' ? content : String(content);
    
    // Check if the string is just whitespace
    if (!messageContent.trim()) {
      console.warn('Empty string content received');
      return <p>Boş yanıt alındı. Lütfen sorunuzu tekrar ifade edin.</p>;
    }
    
    // Fix common markdown table formatting issues before rendering
    const fixedContent = messageContent
      .replace(/\|\s*\|/g, '|') // Fix double pipes
      .replace(/\|\s*:/g, '|:') // Fix alignment markers
      .replace(/(\n\s*\|[^|]*\|[^|]*\|[^|]*\|[^|]*\|[^|]*\|)\s*\|/g, '$1') // Fix extra trailing pipes in complex tables
      .replace(/(\|\s*---\s*\|\s*---\s*\|\s*--\s*\|\s*---\s*\|\s*---\s*\|)\s*\|/g, '$1'); // Fix separator rows  
  
    // Return markdown component with fixed content
    return (
      <div className="markdown-content">
        <ReactMarkdown>{fixedContent}</ReactMarkdown>
      </div>
    );
  };

  // Create SVG path for portfolio chart
  const createChartPath = () => {
    const values = portfolioData.balanceHistory;
    const max = Math.max(...values) * 1.1;
    const min = Math.min(...values) * 0.9;
    const range = max - min;
    
    const width = 100;
    const height = 40;
    const points = values.map((value, index) => {
      const x = (index / (values.length - 1)) * width;
      const y = height - ((value - min) / range) * height;
      return `${x},${y}`;
    });
    
    return `M ${points.join(' L ')}`;
  };

  // Create area path below the line for gradient
  const createAreaPath = () => {
    const path = createChartPath();
    const width = 100;
    const height = 40;
    return `${path} L ${width},${height} L 0,${height} Z`;
  };

  // Portfolio summary donut chart
  const renderDonutChart = () => {
    const total = portfolioData.allocation.reduce((sum, item) => sum + item.value, 0);
    let startAngle = 0;
    
    return (
      <svg viewBox="0 0 100 100" className="donut-chart">
        {portfolioData.allocation.map((item, index) => {
          const angle = (item.value / total) * 360;
          const endAngle = startAngle + angle;
          
          // Calculate SVG arc path
          const x1 = 50 + 40 * Math.cos((startAngle - 90) * Math.PI / 180);
          const y1 = 50 + 40 * Math.sin((startAngle - 90) * Math.PI / 180);
          const x2 = 50 + 40 * Math.cos((endAngle - 90) * Math.PI / 180);
          const y2 = 50 + 40 * Math.sin((endAngle - 90) * Math.PI / 180);
          
          const largeArc = angle > 180 ? 1 : 0;
          
          const pathData = `M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArc} 1 ${x2} ${y2} Z`;
          
          const result = (
            <path 
              key={index} 
              d={pathData} 
              fill={item.color} 
            />
          );
          
          startAngle = endAngle;
          return result;
        })}
        <circle cx="50" cy="50" r="25" fill="#1f2f54" />
      </svg>
    );
  };

  return (
    <div className="portfolio-assistant">
      {/* Add the wave background elements */}
      <div className="portfolio-wave-background">
        <div className="portfolio-wave"></div>
        <div className="portfolio-wave"></div>
        <div className="portfolio-wave"></div>
      </div>
      
      <NavBar />
      <div className="navbar-spacer"></div>
      <div className="main-container">
        <header className="header">
          <div className="logo-container">
            <div className="logo">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                <path d="M6 7C6 4.79086 7.79086 3 10 3H14C16.2091 3 18 4.79086 18 7V8C18 10.2091 16.2091 12 14 12H10C7.79086 12 6 10.2091 6 8V7ZM14 10C15.1046 10 16 9.10457 16 8V7C16 5.89543 15.1046 5 14 5H10C8.89543 5 8 5.89543 8 7V8C8 9.10457 8.89543 10 10 10H14ZM6 17C6 14.7909 7.79086 13 10 13H14C16.2091 13 18 14.7909 18 17V18C18 20.2091 16.2091 22 14 22H10C7.79086 22 6 20.2091 6 18V17ZM14 20C15.1046 20 16 19.1046 16 18V17C16 15.8954 15.1046 15 14 15H10C8.89543 15 8 15.8954 8 17V18C8 19.1046 8.89543 20 10 20H14Z" fill="currentColor" />
              </svg>
            </div>
            <h1>Fibabanka Portföy Asistanı</h1>
          </div>
          <p>Yapay zeka destekli yatırım danışmanlığı ile geleceğinizi şekillendirin</p>
          
          <div className="status-container">
            <div className={`status ${agentAvailable ? 'success' : 'warning'}`}>
              {agentAvailable ? 'AI sistemi aktif' : 'Demo modu - Backend bağlantısı yok'}
            </div>
          </div>
        </header>

        <div className="content-container">
          <div className="chat-panel">
            <div className={`chat-container ${isScrolled ? 'scrolled' : ''}`}>
              <div className="messages" ref={messagesContainerRef}>
                {messages.map((message, index) => (
                  <div key={index} className={`message ${message.role}`}>
                    <div className="message-avatar">
                      {message.role === 'assistant' ? 'AI' : 'Siz'}
                    </div>
                    <div className="message-content">
                      {renderMessage(message.content)}
                      <div className="message-timestamp">
                        {formatTimestamp(message.timestamp)}
                      </div>
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="message assistant">
                    <div className="message-avatar">AI</div>
                    <div className="message-content">
                      <div className="loading">
                        Asistanınız düşünüyor
                        <div className="loading-dots">
                          <div className="loading-dot"></div>
                          <div className="loading-dot"></div>
                          <div className="loading-dot"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Place the quick start section right in the messages area after initial message */}
                {messages.length === 1 && (
                  <div className="message assistant quick-start-message">
                    <div className="message-avatar">AI</div>
                    <div className="message-content">
                      <div className="example-scenario">
                        <div className="quick-start-header">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M5 3v4M3 5h4M6 17v4M4 19h4M13 3l4 4L3 21l4-4L13 3z"/>
                          </svg>
                          <h3>Hızlı Başlangıç</h3>
                        </div>
                        <p className="quick-start-instruction">
                          <strong>Yatırım hedefinizi</strong> yazarak başlayın veya aşağıdaki <strong>örnek senaryoyu</strong> deneyin:
                        </p>
                        <div className="examples-container">
                          <button 
                            className="example-button"
                            onClick={handleExampleScenario}
                          >
                            <span className="button-icon">💰</span>
                            <span>55.000 TL yatırım senaryosu</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {!autoScroll && messages.length > 2 && (
                <button 
                  className="scroll-bottom-button" 
                  onClick={handleManualScroll}
                  aria-label="Scroll to bottom"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                    <path d="M12 16l-6-6h12l-6 6z" fill="currentColor" />
                  </svg>
                </button>
              )}

              <div className="input-area">
                <form onSubmit={handleSubmit}>
                  <div className="input-container">
                    <input
                      type="text"
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      placeholder="Yatırım hedefinizi veya sorunuzu yazın..."
                      disabled={isLoading}
                      className="message-input"
                    />
                    <div className="input-buttons">
                      <button 
                        type="submit" 
                        disabled={isLoading || !currentMessage.trim()}
                        className="send-button"
                      >
                        {isLoading ? 'Gönderiliyor...' : 'Gönder'}
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                          <path d="M3.5 12.6L20.5 3.6C20.9 3.4 21.4 3.7 21.5 4.1C21.5 4.2 21.5 4.4 21.5 4.5V19.5C21.5 19.9 21.2 20.3 20.8 20.3C20.7 20.3 20.5 20.3 20.4 20.2L3.4 11.2C3.1 11.1 2.9 10.6 3 10.3C3.1 10.1 3.3 9.9 3.5 9.9L13.5 12L3.5 12.6Z" fill="currentColor" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>

          <aside className="sidebar">
            <div className="widget portfolio-summary">
              <div className="summary-header">
                <div className="widget-title">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-2a8 8 0 100-16 8 8 0 000 16zm-3.5-6H14a.5.5 0 000-1h-4a2.5 2.5 0 110-5h1V6h2v2h4a.5.5 0 000-1h-4a2.5 2.5 0 110 5h1v2h-2v-2H8.5a.5.5 0 000 1z" fill="currentColor"/>
                  </svg>
                  Portföy Özeti
                </div>
                <div className="portfolio-total">
                  <div className="total-value">₺ {portfolioData.totalValue.toLocaleString('tr-TR')}</div>
                  <div className={`growth-indicator ${portfolioData.growth >= 0 ? 'positive' : 'negative'}`}>
                    {portfolioData.growth >= 0 ? '+' : ''}{portfolioData.growth}%
                  </div>
                </div>
              </div>
              <div className="summary-body">
                {/* Portfolio value chart */}
                <div className="portfolio-chart">
                  <svg viewBox="0 0 100 40" className="value-chart">
                    <defs>
                      <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#58a7ff" stopOpacity="0.3" />
                        <stop offset="100%" stopColor="#58a7ff" stopOpacity="0.01" />
                      </linearGradient>
                    </defs>
                    {/* Chart line */}
                    <path 
                      d={createChartPath()}
                      stroke="#58a7ff"
                      strokeWidth="2"
                      fill="none"
                    />
                    {/* Area below the line with gradient */}
                    <path 
                      d={createAreaPath()}
                      fill="url(#chartGradient)"
                    />
                  </svg>
                  <div className="chart-labels">
                    {portfolioData.dates.map((date, i) => (
                      <div key={i} className="chart-label">
                        {/* Improved date display with better formatting */}
                        {i % 2 === 0 ? 
                          <span className="date-value">{date.split(' ')[0]}<span className="date-month">{date.split(' ')[1].substring(0, 3)}</span></span> : 
                          ''}
                      </div>
                    ))}
                  </div>
                </div>
                
                <h4 className="section-title">Varlık Dağılımı</h4>
                <div className="allocation-chart-container">
                  {renderDonutChart()}
                  <div className="asset-allocation">
                    {portfolioData.allocation.map((asset, index) => (
                      <div key={index} className="allocation-item">
                        <div className="allocation-label">
                          <div className="allocation-indicator" style={{backgroundColor: asset.color}}></div>
                          {asset.name}
                        </div>
                        <div className="allocation-value">{asset.value}%</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="summary-footer">
                <button className="view-details-button" onClick={() => window.location.href='/dashboard'}>
                  Tüm Portföyü Görüntüle
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16">
                    <path d="M13.172 12l-4.95-4.95 1.414-1.414L16 12l-6.364 6.364-1.414-1.414z" fill="currentColor"/>
                  </svg>
                </button>
              </div>
            </div>

            <div className="widget">
              <div className="widget-title">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                  <path d="M4 3h16a1 1 0 011 1v16a1 1 0 01-1 1H4a1 1 0 01-1-1V4a1 1 0 011-1zm1 2v14h14V5H5zm2 2h10v10H7V7zm2 2v6h6V9H9z" fill="currentColor"/>
                </svg>
                Piyasa Verileri
              </div>
              <div className="market-stats">
                <div className="stat-item">
                  <div className="stat-label">BIST100</div>
                  <div className="stat-value up">9,325.42 (+1.2%)</div>
                </div>
                <div className="stat-item">
                  <div className="stat-label">USD/TRY</div>
                  <div className="stat-value down">32.55 (-0.3%)</div>
                </div>
                <div className="stat-item">
                  <div className="stat-label">EUR/TRY</div>
                  <div className="stat-value down">34.80 (-0.1%)</div>
                </div>
                <div className="stat-item">
                  <div className="stat-label">Altın</div>
                  <div className="stat-value up">2,150.75 (+0.8%)</div>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};

export default PortfolioAssistant;


