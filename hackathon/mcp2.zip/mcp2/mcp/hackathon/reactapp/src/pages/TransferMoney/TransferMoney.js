import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './TransferMoney.css';

function TransferMoney() {
  const navigate = useNavigate();
  const [transferData, setTransferData] = useState({
    fromAccount: '',
    toAccount: '',
    amount: '',
    description: ''
  });
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  // Mock accounts data
  const accounts = [
    { id: '1234', name: 'Vadesiz TL Hesabı', balance: 15420.75, currency: 'TL' },
    { id: '5678', name: 'Dolar Hesabı', balance: 2350.00, currency: 'USD' },
    { id: '9012', name: 'Euro Hesabı', balance: 1800.50, currency: 'EUR' },
  ];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTransferData({
      ...transferData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      setIsComplete(true);
    }, 2000);
  };

  if (isComplete) {
    return (
      <div className="transfer-money-container">
        <div className="transfer-card success">
          <div className="success-icon">✓</div>
          <h2>Transfer Başarılı</h2>
          <div className="transfer-details">
            <div className="detail-item">
              <span>Gönderilen Tutar:</span>
              <span>{Number(transferData.amount).toLocaleString('tr-TR')} TL</span>
            </div>
            <div className="detail-item">
              <span>Alıcı Hesap:</span>
              <span>{transferData.toAccount}</span>
            </div>
            <div className="detail-item">
              <span>İşlem Tarihi:</span>
              <span>{new Date().toLocaleDateString('tr-TR')}</span>
            </div>
            <div className="detail-item">
              <span>İşlem Saati:</span>
              <span>{new Date().toLocaleTimeString('tr-TR')}</span>
            </div>
            <div className="detail-item">
              <span>Referans No:</span>
              <span>{Math.random().toString(36).substring(2, 10).toUpperCase()}</span>
            </div>
          </div>
          <div className="button-group">
            <button onClick={() => navigate("/homePage")} className="back-button">
              Ana Sayfaya Dön
            </button>
            <button onClick={() => {
              setIsComplete(false);
              setTransferData({
                fromAccount: '',
                toAccount: '',
                amount: '',
                description: ''
              });
            }} className="new-transfer-button">
              Yeni Transfer
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="transfer-money-container">
      <div className="transfer-card">
        <h1>Para Transferi</h1>
        <p className="subtitle">Hesaplarınız arasında veya başka hesaplara para transferi yapın</p>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Gönderen Hesap</label>
            <select
              name="fromAccount"
              value={transferData.fromAccount}
              onChange={handleChange}
              required
            >
              <option value="">Hesap Seçin</option>
              {accounts.map(account => (
                <option key={account.id} value={account.id}>
                  {account.name} - {account.balance.toLocaleString('tr-TR')} {account.currency}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Alıcı Hesap</label>
            <select
              name="toAccount"
              value={transferData.toAccount}
              onChange={handleChange}
              required
            >
              <option value="">Hesap Seçin</option>
              <option value="own">Kendi Hesabıma</option>
              <option value="other">Başka Hesaba</option>
            </select>
          </div>

          {transferData.toAccount === 'own' && (
            <div className="form-group">
              <label>Hangi Hesabınıza?</label>
              <select
                name="ownAccount"
                onChange={handleChange}
                required={transferData.toAccount === 'own'}
              >
                <option value="">Hesap Seçin</option>
                {accounts
                  .filter(account => account.id !== transferData.fromAccount)
                  .map(account => (
                    <option key={account.id} value={account.id}>
                      {account.name} - {account.balance.toLocaleString('tr-TR')} {account.currency}
                    </option>
                  ))}
              </select>
            </div>
          )}

          {transferData.toAccount === 'other' && (
            <div className="form-group">
              <label>IBAN</label>
              <input
                type="text"
                name="iban"
                placeholder="TR00 0000 0000 0000 0000 0000 00"
                onChange={handleChange}
                required={transferData.toAccount === 'other'}
              />
            </div>
          )}

          <div className="form-group">
            <label>Tutar (TL)</label>
            <input
              type="number"
              name="amount"
              value={transferData.amount}
              onChange={handleChange}
              min="1"
              step="0.01"
              placeholder="0.00"
              required
            />
          </div>

          <div className="form-group">
            <label>Açıklama (Opsiyonel)</label>
            <textarea
              name="description"
              value={transferData.description}
              onChange={handleChange}
              rows="3"
              placeholder="Transfer açıklaması girin"
            ></textarea>
          </div>

          <div className="button-group">
            <button type="button" onClick={() => navigate("/homePage")} className="back-button">
              İptal
            </button>
            <button 
              type="submit" 
              className="submit-button"
              disabled={isProcessing}
            >
              {isProcessing ? 'İşleniyor...' : 'Transferi Başlat'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default TransferMoney;
