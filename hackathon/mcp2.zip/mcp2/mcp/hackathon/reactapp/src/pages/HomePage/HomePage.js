import React from "react";
import { useNavigate } from "react-router-dom";
import NavBar from '../../components/NavBar/NavBar';
import './HomePage.css';

function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="home-page-wrapper">
      {/* Add the wave background elements */}
      <div className="wave-background">
        <div className="wave"></div>
        <div className="wave"></div>
        <div className="wave"></div>
      </div>
      
      <NavBar />
      <div className="navbar-spacer"></div>
      <div className="home-page-container">
        <header className="page-header">
          <h1>Fibabanka Müşteri Ana Sayfası</h1>
          <p>Hoşgeldiniz! Finansal işlemlerinizi güvenle yönetin.</p>
        </header>

        <div className="options-grid">
          <div className="option-card" onClick={() => navigate("/portfolio")}>
            <div className="option-icon">📊</div>
            <h2>Portföy Asistanı</h2>
            <p>Yapay zeka destekli yatırım danışmanlığı</p>
            <p>
              Finansal hedeflerinize ulaşmak için yapay zeka destekli portföy asistanımız 
              size özel yatırım tavsiyeleri sunuyor.
            </p>
            <button onClick={() => navigate("/portfolio")} className="portfolio-button">
              Portföy Asistanına Git
            </button>
          </div>
          
          <div className="option-card" onClick={() => navigate("/transferMoney")}>
            <div className="option-icon">💸</div>
            <h2>Para Transferi</h2>
            <p>Hesaplar arası para transferi yapın</p>
          </div>
          
          <div className="option-card">
            <div className="option-icon">💰</div>
            <h2>Hesap Özetleri</h2>
            <p>Hesaplarınızın durumunu görüntüleyin</p>
          </div>
          
          <div className="option-card">
            <div className="option-icon">📱</div>
            <h2>Mobil İşlemler</h2>
            <p>Mobil bankacılık hizmetleri</p>
          </div>
        </div>

        <button className="back-button" onClick={() => navigate("/")}>
          Ana Sayfaya Dön
        </button>
      </div>
    </div>
  );
}

export default HomePage;
