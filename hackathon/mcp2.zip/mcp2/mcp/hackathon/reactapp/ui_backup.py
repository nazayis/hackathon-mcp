# ui_backup.py

import streamlit as st
from dotenv import load_dotenv
import asyncio
import uuid

# Ortam değişkenlerini yükle
load_dotenv()

# --- 1. SAYFA YAPILANDIRMASI ---
st.set_page_config(layout="wide", page_title="Fibabanka Portföy Asistanı (Backup)")

# --- Ajan Mantığının İçe Aktarılması ---
try:
    from agent import run_portfolio_interaction, riskometre_kb
    AGENT_AVAILABLE = True
    st.success("✅ Ana AI sistemi yüklendi")
except ImportError as e:
    st.warning("⚠️ Ana AI sistemi bulunamadı, demo moduna geçiliyor...")
    try:
        from mock_agent import run_portfolio_interaction, riskometre_kb
        AGENT_AVAILABLE = True
        st.info("🤖 Demo AI asistanı aktif")
    except ImportError as e2:
        st.error(f"Demo sistem de yüklenemedi: {e2}")
        AGENT_AVAILABLE = False
        
        # Fallback functions
        async def run_portfolio_interaction(user_id, session_id, user_message):
            return "Üzgünüm, şu anda AI asistanı kullanılamıyor. Lütfen sistem yöneticisi ile iletişime geçin."
        
        class MockKB:
            def load(self, recreate=False):
                pass
        
        riskometre_kb = MockKB()

# --- Asenkron Olay Döngüsü Yönetimi ---
def get_or_create_event_loop():
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop

# --- Bilgi Bankası Yükleme ---
@st.cache_resource
def load_knowledge_base():
    if not AGENT_AVAILABLE:
        st.warning("⚠️ Agent modülü mevcut olmadığı için bilgi bankası yüklenemedi.")
        return
    
    progress_bar = st.progress(0, text="Bilgi Bankası ilk kez yükleniyor...")
    try:
        riskometre_kb.load(recreate=False) 
        progress_bar.progress(100, text="Bilgi Bankası başarıyla yüklendi!")
    except Exception as e:
        progress_bar.empty()
        st.error(f"Bilgi Bankası yüklenirken bir hata oluştu: {e}")

# --- 2. BİLGİ BANKASI YÜKLEME ---
load_knowledge_base()

# --- 3. SAYFA BAŞLIKLARI VE ARAYÜZ ---
st.title("📈 Fibabanka Portföy Asistanı (Backup Version)")
st.caption("Riskometre verileri ve yapay zeka ile yatırımlarınızı yönetin.")

# --- Oturum Durumu (Session State) ---
if "messages" not in st.session_state:
    st.session_state.messages = []
    st.session_state.user_id = "hackathon_user"
    st.session_state.session_id = str(uuid.uuid4())
    st.session_state.messages.append({
        "role": "assistant",
        "content": "Merhaba! Ben Fibabanka Portföy Asistanınız (Backup Version). Yatırımlarınızı yönetmenize nasıl yardımcı olabilirim?"
    })

# --- Sohbet Geçmişini Göster ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- Örnek Senaryo Arayüzü ---
if len(st.session_state.messages) == 1:
    st.markdown("---")
    st.write("Yatırım hedefinizi yazarak başlayın veya bir örnek senaryo deneyin:")
    investment_scenario_text = "Merhaba, 55.000 TL yatırım yapmak istiyorum. Mevcut piyasa koşullarına göre ılımlı bir riskle paramı nasıl değerlendirebilirim?"
    if st.button("💰 55.000 TL yatırım senaryosunu dene"):
        st.session_state.prompt_from_button = investment_scenario_text
        st.rerun()

# --- Ana Etkileşim Döngüsü ---
prompt = st.chat_input("Yatırım hedefinizi veya sorunuzu yazın...")

# Check if the button set a prompt
if "prompt_from_button" in st.session_state and st.session_state.prompt_from_button:
    prompt = st.session_state.prompt_from_button
    del st.session_state.prompt_from_button

if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        if not AGENT_AVAILABLE:
            st.error("AI asistanı şu anda kullanılamıyor.")
            ai_response = "Üzgünüm, şu anda teknik bir sorun yaşanıyor."
        else:
            with st.spinner("Asistanınız sizin için en iyi yatırım seçeneklerini düşünüyor..."):
                loop = get_or_create_event_loop()
                
                ai_response = loop.run_until_complete(
                    run_portfolio_interaction(
                        user_id=st.session_state.user_id,
                        session_id=st.session_state.session_id,
                        user_message=prompt
                    )
                )
        st.markdown(ai_response)
    
    st.session_state.messages.append({"role": "assistant", "content": ai_response})
    st.rerun()
