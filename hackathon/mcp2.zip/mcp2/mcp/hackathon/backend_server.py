import os
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncio
from pathlib import Path
import uvicorn
from dotenv import load_dotenv
import sqlite3
import json
from datetime import datetime, timedelta
import random

# Load environment variables
load_dotenv()

# Global flags to prevent duplicate initialization
_AGENT_INITIALIZED = False
_KB_INITIALIZED = False

# Try to import the agent functionality
try:
    from agent import run_portfolio_interaction, riskometre_kb
    AGENT_AVAILABLE = True
    if not _AGENT_INITIALIZED:
        print("Agent module loaded successfully with Gemini AI")
        _AGENT_INITIALIZED = True
except Exception as e:
    if not _AGENT_INITIALIZED:
        print(f"Agent module not available: {e}")
        _AGENT_INITIALIZED = True
    AGENT_AVAILABLE = False

# Import our MCP manager
from mcp_manager import get_mcp_manager

app = FastAPI(title="Fibabanka Portfolio Assistant API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request models
class PortfolioRequest(BaseModel):
    user_id: str
    session_id: str
    user_message: str

class HealthResponse(BaseModel):
    available: bool
    message: str

# New models for dashboard data
class DashboardDataResponse(BaseModel):
    portfolio_data: dict
    ai_recommendations_data: dict
    market_data: dict

# API endpoints
@app.get("/api/check-agent", response_model=HealthResponse)
async def check_agent():
    if AGENT_AVAILABLE:
        message = "Agent is available with Gemini AI services"
    else:
        message = "Agent not available - please check Google Gemini API key in .env file"
    
    return HealthResponse(
        available=AGENT_AVAILABLE,
        message=message
    )

@app.post("/api/portfolio-interaction")
async def portfolio_interaction(request: PortfolioRequest):
    try:
        if not AGENT_AVAILABLE:
            print("Agent not available, returning error")
            raise HTTPException(
                status_code=503, 
                detail="AI agent not available. Please check server configuration and API keys."
            )
        
        print(f"Processing request: {request.user_message}")
        print(f"User ID: {request.user_id}, Session ID: {request.session_id}")
        
        response = await run_portfolio_interaction(
            user_id=request.user_id,
            session_id=request.session_id,
            user_message=request.user_message
        )
        
        print(f"Raw response from agent: {repr(response)}")
        print(f"Response type: {type(response)}")
        
        # Ensure response is not None or empty
        if response is None:
            print("Response is None - this indicates the agent function returned None")
            response = "Sorry, I couldn't process your request. Please try again."
        elif not isinstance(response, str):
            print(f"Response is not a string: {type(response)}")
            response = str(response)
        elif not response.strip():
            print("Response is empty string")
            response = "I received your message but couldn't generate a response. Please try rephrasing your question."
        
        print(f"Final response being sent: {response}")
        return {"response": response}
        
    except Exception as e:
        error_msg = f"Error in portfolio interaction: {e}"
        print(error_msg)
        import traceback
        traceback.print_exc()
        
        # Return a user-friendly error message instead of raising HTTP exception
        return {
            "response": "I'm experiencing technical difficulties. Please try again in a moment.",
            "error": True
        }

# Dashboard data endpoints
@app.get("/api/dashboard-data")
async def get_dashboard_data():
    """Get portfolio, AI recommendations, and market data for the dashboard"""
    try:
        # Get real data from database
        portfolio_data = get_portfolio_data()
        ai_recommendations_data = get_ai_recommendations_data()
        market_data = get_market_data()
        
        return {
            "portfolio_data": portfolio_data,
            "ai_recommendations_data": ai_recommendations_data,
            "market_data": market_data
        }
    except Exception as e:
        print(f"Error retrieving dashboard data: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to retrieve dashboard data: {str(e)}")

def get_portfolio_data():
    """Get real portfolio data from database"""
    try:
        # Connect to SQLite database
        db_path = Path(__file__).parent / "output" / "portfolio_data.db"
        
        # If database doesn't exist yet, create sample data
        if not db_path.exists():
            initialize_portfolio_database(db_path)
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Get total portfolio value
        cursor.execute("SELECT SUM(current_value) FROM assets")
        total_value = cursor.fetchone()[0]
        
        # Calculate growth
        cursor.execute("SELECT SUM(current_value - initial_value) / SUM(initial_value) * 100 FROM assets")
        growth = cursor.fetchone()[0]
        
        # Get asset allocation
        cursor.execute("SELECT asset_type, SUM(current_value) FROM assets GROUP BY asset_type")
        allocation_rows = cursor.fetchall()
        
        asset_allocation = []
        for asset_type, value in allocation_rows:
            percentage = (value / total_value) * 100
            asset_allocation.append({
                "name": asset_type,
                "value": round(percentage, 1)
            })
        
        # Get recent transactions
        cursor.execute("""
            SELECT date, description, amount, transaction_type 
            FROM transactions 
            ORDER BY date DESC LIMIT 4
        """)
        transactions = cursor.fetchall()
        
        recent_transactions = []
        for date, description, amount, transaction_type in transactions:
            recent_transactions.append({
                "date": date,
                "description": description,
                "amount": amount,
                "type": transaction_type
            })
        
        conn.close()
        
        return {
            "totalValue": total_value,
            "growth": round(growth, 1),
            "assetAllocation": asset_allocation,
            "recentTransactions": recent_transactions
        }
    
    except Exception as e:
        print(f"Error getting portfolio data: {e}")
        raise

def get_ai_recommendations_data():
    """Get real AI recommendation data from database"""
    try:
        # Connect to SQLite database
        db_path = Path(__file__).parent / "output" / "portfolio_data.db"
        
        # If database doesn't exist yet, create sample data
        if not db_path.exists():
            initialize_portfolio_database(db_path)
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Get recommendations
        cursor.execute("""
            SELECT id, date, initial_investment, current_value, expected_return, 
                   actual_return, performance_difference, status, notes
            FROM ai_recommendations
            ORDER BY date DESC
        """)
        recommendation_rows = cursor.fetchall()
        
        recommendations = []
        total_investment = 0
        total_current_value = 0
        expected_returns = []
        actual_returns = []
        
        for row in recommendation_rows:
            id, date, initial_investment, current_value, expected_return, actual_return, performance_difference, status, notes = row
            
            # Get assets for this recommendation
            cursor.execute("""
                SELECT symbol, name, allocation, expected_return, actual_return
                FROM recommendation_assets
                WHERE recommendation_id = ?
            """, (id,))
            asset_rows = cursor.fetchall()
            
            assets = []
            for asset_row in asset_rows:
                symbol, name, allocation, asset_expected_return, asset_actual_return = asset_row
                assets.append({
                    "symbol": symbol,
                    "name": name,
                    "allocation": allocation,
                    "expectedReturn": asset_expected_return,
                    "actualReturn": asset_actual_return
                })
            
            recommendation = {
                "id": id,
                "date": date,
                "assets": assets,
                "initialInvestment": initial_investment,
                "currentValue": current_value,
                "expectedReturnTotal": expected_return,
                "actualReturnTotal": actual_return,
                "performanceDifference": performance_difference,
                "status": status,
                "notes": notes
            }
            
            recommendations.append(recommendation)
            total_investment += initial_investment
            total_current_value += current_value
            expected_returns.append(expected_return)
            actual_returns.append(actual_return)
        
        # Calculate aggregate stats
        avg_expected_return = sum(expected_returns) / len(expected_returns) if expected_returns else 0
        avg_actual_return = sum(actual_returns) / len(actual_returns) if actual_returns else 0
        overall_performance = avg_actual_return - avg_expected_return
        
        # Get best and worst performers
        cursor.execute("""
            SELECT symbol, actual_return FROM recommendation_assets
            ORDER BY actual_return DESC LIMIT 1
        """)
        best_row = cursor.fetchone()
        best_performer = {"symbol": best_row[0], "return": best_row[1]} if best_row else {"symbol": "N/A", "return": 0}
        
        cursor.execute("""
            SELECT symbol, actual_return FROM recommendation_assets
            ORDER BY actual_return ASC LIMIT 1
        """)
        worst_row = cursor.fetchone()
        worst_performer = {"symbol": worst_row[0], "return": worst_row[1]} if worst_row else {"symbol": "N/A", "return": 0}
        
        # Calculate success rate
        cursor.execute("""
            SELECT COUNT(*) FROM ai_recommendations
            WHERE actual_return >= expected_return
        """)
        successful_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM ai_recommendations")
        total_count = cursor.fetchone()[0]
        success_rate = (successful_count / total_count * 100) if total_count > 0 else 0
        
        conn.close()
        
        return {
            "recommendations": recommendations,
            "totalInvestmentAmount": total_investment,
            "totalCurrentValue": total_current_value,
            "averageExpectedReturn": round(avg_expected_return, 1),
            "averageActualReturn": round(avg_actual_return, 1),
            "overallPerformance": round(overall_performance, 1),
            "successRate": round(success_rate, 1),
            "bestPerformer": best_performer,
            "worstPerformer": worst_performer
        }
    
    except Exception as e:
        print(f"Error getting AI recommendations data: {e}")
        raise

def get_market_data():
    """Get real market data from database or external API"""
    try:
        # Connect to SQLite database
        db_path = Path(__file__).parent / "output" / "portfolio_data.db"
        
        # If database doesn't exist yet, create sample data
        if not db_path.exists():
            initialize_portfolio_database(db_path)
        
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Get market data
        cursor.execute("SELECT name, value, change FROM market_indices")
        indices = cursor.fetchall()
        
        cursor.execute("SELECT name, value, change FROM market_currencies")
        currencies = cursor.fetchall()
        
        cursor.execute("SELECT name, value, change FROM market_commodities")
        commodities = cursor.fetchall()
        
        conn.close()
        
        return {
            "indices": [{"name": name, "value": value, "change": change} for name, value, change in indices],
            "currencies": [{"name": name, "value": value, "change": change} for name, value, change in currencies],
            "commodities": [{"name": name, "value": value, "change": change} for name, value, change in commodities]
        }
    
    except Exception as e:
        print(f"Error getting market data: {e}")
        raise

def initialize_portfolio_database(db_path):
    """Create and initialize the portfolio database with sample data"""
    print(f"Creating new portfolio database at {db_path}")
    
    # Create database directory if it doesn't exist
    db_path.parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    # Create assets table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS assets (
        id INTEGER PRIMARY KEY,
        asset_type TEXT NOT NULL,
        symbol TEXT NOT NULL,
        name TEXT NOT NULL,
        initial_value REAL NOT NULL,
        current_value REAL NOT NULL,
        purchase_date TEXT NOT NULL
    )
    """)
    
    # Create transactions table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY,
        date TEXT NOT NULL,
        description TEXT NOT NULL,
        amount REAL NOT NULL,
        transaction_type TEXT NOT NULL
    )
    """)
    
    # Create AI recommendations table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ai_recommendations (
        id INTEGER PRIMARY KEY,
        date TEXT NOT NULL,
        initial_investment REAL NOT NULL,
        current_value REAL NOT NULL,
        expected_return REAL NOT NULL,
        actual_return REAL NOT NULL,
        performance_difference REAL NOT NULL,
        status TEXT NOT NULL,
        notes TEXT
    )
    """)
    
    # Create recommendation assets table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS recommendation_assets (
        id INTEGER PRIMARY KEY,
        recommendation_id INTEGER NOT NULL,
        symbol TEXT NOT NULL,
        name TEXT NOT NULL,
        allocation INTEGER NOT NULL,
        expected_return REAL NOT NULL,
        actual_return REAL NOT NULL,
        FOREIGN KEY (recommendation_id) REFERENCES ai_recommendations (id)
    )
    """)
    
    # Create market data tables
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS market_indices (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        value REAL NOT NULL,
        change REAL NOT NULL
    )
    """)
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS market_currencies (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        value REAL NOT NULL,
        change REAL NOT NULL
    )
    """)
    
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS market_commodities (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        value REAL NOT NULL,
        change REAL NOT NULL
    )
    """)
    
    # Insert sample data
    
    # Assets
    assets = [
        ("Hisse Senetleri", "THYAO", "Türk Hava Yolları", 50000, 60000, "2023-08-01"),
        ("Hisse Senetleri", "GARAN", "Garanti Bankası", 40000, 42000, "2023-09-15"),
        ("Tahvil/Bono", "TGB240724T14", "TGB 2 Yıllık", 80000, 84000, "2023-07-24"),
        ("Nakit", "TRY", "Türk Lirası", 55000, 55000, "2023-10-01"),
        ("Altın", "XAU", "Altın (gr)", 100000, 105000, "2023-06-15")
    ]
    
    cursor.executemany("""
    INSERT INTO assets (asset_type, symbol, name, initial_value, current_value, purchase_date)
    VALUES (?, ?, ?, ?, ?, ?)
    """, assets)
    
    # Transactions
    today = datetime.now().strftime("%Y-%m-%d")
    week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    two_weeks_ago = (datetime.now() - timedelta(days=14)).strftime("%Y-%m-%d")
    month_ago = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    
    transactions = [
        (today, "THYAO Alış", -15000, "buy"),
        (week_ago, "Temettü Ödemesi", 1250, "dividend"),
        (two_weeks_ago, "YKBNK Satış", 22000, "sell"),
        (month_ago, "GARAN Alış", -18500, "buy")
    ]
    
    cursor.executemany("""
    INSERT INTO transactions (date, description, amount, transaction_type)
    VALUES (?, ?, ?, ?)
    """, transactions)
    
    # AI Recommendations
    three_months_ago = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
    two_months_ago = (datetime.now() - timedelta(days=60)).strftime("%Y-%m-%d")
    one_month_ago = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    
    recommendations = [
        (three_months_ago, 50000, 56850, 9.2, 13.7, 4.5, "outperformed", "Özellikle havacılık sektöründeki yükseliş beklentileri aştı."),
        (two_months_ago, 75000, 80625, 10.5, 7.5, -3.0, "underperformed", "Bankacılık sektöründeki beklenmedik düzenlemeler getiriyi olumsuz etkiledi."),
        (one_month_ago, 100000, 112300, 9.8, 12.3, 2.5, "outperformed", "Enerji ve ulaşım sektörlerinde güçlü performans.")
    ]
    
    for i, (date, investment, value, expected, actual, diff, status, notes) in enumerate(recommendations):
        cursor.execute("""
        INSERT INTO ai_recommendations (date, initial_investment, current_value, expected_return, actual_return, performance_difference, status, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (date, investment, value, expected, actual, diff, status, notes))
        
        recommendation_id = i + 1
        
        if recommendation_id == 1:
            assets = [
                ("THYAO", "Türk Hava Yolları", 25, 12, 15.7),
                ("GARAN", "Garanti Bankası", 20, 8, 6.2),
                ("KRDMD", "Kardemir", 15, 10, 11.3),
                ("EREGL", "Ereğli Demir Çelik", 30, 7.5, 9.8),
                ("SISE", "Şişe Cam", 10, 9, 8.5)
            ]
        elif recommendation_id == 2:
            assets = [
                ("VAKBN", "Vakıfbank", 35, 11, 8.3),
                ("KOZAL", "Koza Altın", 25, 15, 17.2),
                ("AKBNK", "Akbank", 20, 9, 7.1),
                ("BIMAS", "BİM Mağazaları", 20, 6, 9.4)
            ]
        else:
            assets = [
                ("TUPRS", "Tüpraş", 30, 8, 10.8),
                ("SAHOL", "Sabancı Holding", 25, 7, 7.2),
                ("TAVHL", "TAV Havalimanları", 25, 12, 14.5),
                ("PGSUS", "Pegasus", 20, 14, 15.7)
            ]
        
        for symbol, name, allocation, expected_return, actual_return in assets:
            cursor.execute("""
            INSERT INTO recommendation_assets (recommendation_id, symbol, name, allocation, expected_return, actual_return)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (recommendation_id, symbol, name, allocation, expected_return, actual_return))
    
    # Market data
    indices = [
        ("BIST100", 9325.42, 1.2),
        ("BIST30", 9948.76, 0.8),
        ("BIST Bank", 5432.21, -0.5)
    ]
    
    cursor.executemany("""
    INSERT INTO market_indices (name, value, change)
    VALUES (?, ?, ?)
    """, indices)
    
    currencies = [
        ("USD/TRY", 32.55, -0.3),
        ("EUR/TRY", 34.80, -0.1),
        ("GBP/TRY", 40.12, 0.2)
    ]
    
    cursor.executemany("""
    INSERT INTO market_currencies (name, value, change)
    VALUES (?, ?, ?)
    """, currencies)
    
    commodities = [
        ("Altın (gram)", 2150.75, 0.8),
        ("Brent Petrol", 75.32, -1.2),
        ("Gümüş (ons)", 28.45, 0.5)
    ]
    
    cursor.executemany("""
    INSERT INTO market_commodities (name, value, change)
    VALUES (?, ?, ?)
    """, commodities)
    
    conn.commit()
    conn.close()
    print("Database initialized with sample data")

# Initialize knowledge base if agent is available
if AGENT_AVAILABLE and not _KB_INITIALIZED:
    try:
        riskometre_kb.load(recreate=False)
        print("Knowledge base loaded successfully")
        _KB_INITIALIZED = True
    except Exception as e:
        print(f"Knowledge base loading failed: {e}")
        AGENT_AVAILABLE = False
        _KB_INITIALIZED = True

# Serve React static files
react_build_path = Path(__file__).parent / "reactapp" / "build"

print(f"Looking for React build at: {react_build_path}")

if react_build_path.exists():
    print(f"React build found at {react_build_path}")
    app.mount("/static", StaticFiles(directory=str(react_build_path / "static")), name="static")
    
    @app.get("/")
    async def serve_react_app():
        return FileResponse(str(react_build_path / "index.html"))
    
    @app.get("/{path:path}")
    async def serve_react_routes(path: str):
        file_path = react_build_path / path
        if file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(react_build_path / "index.html"))
else:
    print(f"React build not found at {react_build_path}")
    @app.get("/")
    async def root():
        return {
            "message": "Fibabanka Portfolio Assistant API", 
            "note": "React build not found. Please build the React app first.",
            "agent_available": AGENT_AVAILABLE,
            "path_checked": str(react_build_path)
        }

# Add FastAPI lifecycle event to manage MCP tools
@app.on_event("startup")
async def startup_event():
    if AGENT_AVAILABLE:
        print("Initializing MCP manager on startup...")
        await get_mcp_manager()

@app.on_event("shutdown")
async def shutdown_event():
    if AGENT_AVAILABLE:
        print("Shutting down MCP manager...")
        mcp_manager = await get_mcp_manager()
        await mcp_manager.close()

if __name__ == "__main__":
    if not _AGENT_INITIALIZED or not _KB_INITIALIZED:
        print("Starting Fibabanka Portfolio Assistant Server...")
        print(f"Agent Available: {AGENT_AVAILABLE}")
        
        if not AGENT_AVAILABLE:
            print("To enable AI features:")
            print("1. Ensure Google Gemini API key is in .env file")
            print("2. Install agno: pip install agno")
            print("3. Get API key from: https://aistudio.google.com/app/apikey")
    
    # Use import string to avoid reload warning
    uvicorn.run("backend_server:app", host="0.0.0.0", port=8000, reload=True)
